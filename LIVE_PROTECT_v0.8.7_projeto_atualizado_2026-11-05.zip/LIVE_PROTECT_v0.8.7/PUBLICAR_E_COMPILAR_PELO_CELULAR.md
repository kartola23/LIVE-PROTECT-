# LIVE PROTECT 0.8.7 — publicar e compilar pelo celular

O projeto está empacotado em um ZIP. O repositório está acessível para leitura, mas a gravação pela integração GitHub foi recusada com HTTP 403. Por isso, a publicação deve ser feita pelo navegador do celular. O código-fonte completo ainda precisa ser enviado à branch `LIVE-PROTECT`.

## 1. Enviar o ZIP ao repositório

1. Abra https://github.com/kartola23/LIVE-PROTECT- e selecione a branch `LIVE-PROTECT`.
2. Toque em **Add file → Upload files**.
3. Envie `LIVE_PROTECT_v0.8.7_projeto_atualizado_2026-11-05.zip` para a raiz do repositório.
4. Faça **Commit changes**.

## 2. Criar o workflow de compilação

1. No mesmo repositório, escolha **Add file → Create new file**.
2. No nome do arquivo, digite `.github/workflows/android-apk.yml`.
3. Abra o arquivo `LIVE_PROTECT_android-apk_workflow_v0.8.7.yml` fornecido com esta entrega, copie todo o conteúdo e cole no editor do GitHub.
4. Faça **Commit changes** na branch `LIVE-PROTECT`.

## 3. Executar a compilação

1. Abra a aba **Actions** do repositório.
2. Selecione **LIVE PROTECT Android APK**.
3. Toque em **Run workflow** e confirme a branch `LIVE-PROTECT`.
4. Aguarde a execução. Ela só publica o APK se os 31 testes do backend passarem, o build Gradle terminar e `apksigner`/`aapt` confirmarem assinatura e identidade do pacote.
5. Abra a execução concluída, localize **Artifacts** e baixe `LIVE-PROTECT-debug-v0.8.7`.
6. Extraia o artefato no Android, confira o SHA-256 e instale o `app-debug.apk`. O Android poderá pedir permissão para instalar aplicativos dessa origem.

## Observações de segurança e versão

- O artefato gerado pelo workflow é um APK **debug**, assinado pela chave debug temporária do runner GitHub. É apropriado para teste, não para distribuição pública.
- Uma build debug futura poderá usar outra chave; o Android pode exigir desinstalar a versão anterior antes de instalar a nova.
- Não coloque keystore, senhas ou tokens no repositório. O APK release assinado requer keystore privado e segredos configurados em ambiente protegido.
- O build não instala automaticamente o app no telefone; ele apenas entrega o APK verificado para instalação manual.
- A API ainda precisa ser publicada em HTTPS. Os adaptadores de eventos independentes e oficiais continuam desligados; nenhum evento real do TikTok LIVE é capturado neste pacote.
