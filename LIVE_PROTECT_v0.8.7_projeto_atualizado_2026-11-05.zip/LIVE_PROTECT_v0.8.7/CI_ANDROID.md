# Compilação Android pelo GitHub Actions (celular)

O workflow `.github/workflows/android-apk.yml` prepara JDK 21, Gradle 8.9 e Android SDK Platform 35 / Build Tools 35.0.0 em um runner do GitHub. O gatilho de push inclui as branches `LIVE-PROTECT` e `ChatGPT`, além de `main`/`master`, para corresponder às branches existentes no repositório atual. Assim, o telefone só precisa de um navegador; não precisa instalar Android Studio nem SDK localmente.

## Pré-requisito obrigatório

Todo o conteúdo do projeto precisa estar dentro de um repositório GitHub ao qual você tenha acesso de escrita, incluindo a pasta `.github/workflows/`. Um ZIP anexado como arquivo isolado no repositório **não** é suficiente: os arquivos do projeto precisam estar extraídos na raiz.

## Iniciar pelo navegador Android

1. Abra o repositório que contém o projeto completo.
2. Entre em **Actions** e habilite GitHub Actions, se solicitado.
3. Selecione **LIVE PROTECT Android APK** e toque em **Run workflow**.
4. Aguarde os trabalhos **Backend tests** e **Build and verify installable debug APK** terminarem com sucesso. O build Android só começa depois dos testes do backend passarem.
5. Abra a execução concluída, vá a **Artifacts** e baixe `LIVE-PROTECT-debug-v0.8.7` (o nome acompanha a versão do aplicativo).
6. Extraia o ZIP no celular. Confira o SHA-256 do APK com uma ferramenta local antes de instalar. O Android pode pedir autorização para instalar apps dessa origem.

O workflow compila `:app:assembleDebug`, verifica a assinatura debug com `apksigner`, confirma o application ID e o rótulo com `aapt`, e publica também os metadados e o checksum. Se qualquer etapa falhar, nenhum artefato instalável é publicado.

## Importante sobre a versão debug

- O APK debug é assinado automaticamente com a chave debug criada no runner. Serve para avaliação e instalação de teste.
- A chave debug do runner não é uma chave permanente. Um APK futuro assinado com outra chave pode exigir desinstalar a versão anterior, o que pode apagar dados locais.
- Para distribuição pública, será necessário um keystore release próprio e um workflow de release protegido. Não coloque keystore nem senhas no repositório.

## Limites funcionais

A compilação valida o pacote Android, mas não publica a API. A API precisa ser implantada em HTTPS e configurada com segredos próprios. O monitoramento independente continua desligado até existir um provedor tecnicamente revisado e compatível com os termos e permissões aplicáveis. A integração oficial depende de produto/API e autorização do TikTok que concedam os eventos LIVE necessários. Não usar scraping, senha ou sessão do TikTok. Notificações funcionam por consulta enquanto o app está ativo; push em segundo plano exige FCM e serviço de envio no backend.


## Alternativa para quem envia o ZIP como um único arquivo

Se não for possível extrair e enviar a árvore de pastas pelo navegador móvel, envie o ZIP completo para a raiz do repositório e crie `.github/workflows/android-apk.yml` copiando `LIVE_PROTECT_android-apk_workflow_v0.8.7.yml` (ou `ANDROID_APK_WORKFLOW_UPLOAD.yml` dentro do ZIP). Esse workflow extrai o arquivo, executa os testes e compila o APK. Siga `PUBLICAR_E_COMPILAR_PELO_CELULAR.md`. O arquivo ZIP esperado é `LIVE_PROTECT_v0.8.7_projeto_atualizado_2026-11-05.zip`.
