# Estado da integração TikTok — 05/11/2026

## Verificação documental oficial (05/11/2026)

A consulta ao catálogo público do TikTok for Developers confirma produtos como Login Kit, Share Kit, Content Posting API, Display API, Research API e Data Portability API. O catálogo público consultado não apresenta um produto genérico de eventos TikTok LIVE em tempo real para comentários, presentes ou entrada de espectadores. A documentação de Webhook Events consultada descreve eventos de autorização, publicação de conteúdo e disponibilidade de exportação; não foi encontrada ali uma assinatura de eventos LIVE em tempo real. Isso não prova que não exista programa privado/por convite: o responsável deve confirmar diretamente no Developer Portal e com o contato oficial do TikTok antes de projetar um conector.

A Data Portability API documenta categorias de arquivo que incluem TikTok LIVE, como Go LIVE History, Watch LIVE History e LiveStream Comment, com Room ID, horário e conteúdo do comentário. Porém, o produto é um fluxo de solicitação, preparação, consulta de status e download de exportação; não é um feed de eventos de live em tempo real. A documentação informa que os dados podem ser solicitados uma vez ou por permissões ongoing, mas isso não deve ser interpretado como streaming em tempo real.

**Limitação regional relevante:** a página oficial do produto informa que candidatos qualificados podem solicitar acesso globalmente, mas os dados retornados atualmente abrangem somente usuários TikTok do Espaço Econômico Europeu (EEE) e Reino Unido. Portanto, a Data Portability API não é uma solução disponível para importar os dados do criador localizado no Brasil, salvo mudança oficial de cobertura/região. Mesmo para usuários elegíveis, a API exige aprovação separada da aplicação/escopos e do Login Kit; Webhooks também precisam ser configurados se forem usados para avisar que um arquivo está pronto.

## Consequência para o LIVE PROTECT

- O adaptador oficial permanece desativado até haver produto/API, escopos e aprovação que concedam explicitamente os eventos LIVE necessários em tempo real.
- A Data Portability API pode ser estudada para auditoria histórica somente se o usuário dos dados estiver em região elegível e as aprovações/consentimentos forem obtidos; não atende atualmente ao criador no Brasil e não substitui ingestão LIVE.
- O adaptador independente permanece desativado até que uma fonte seja tecnicamente revisada e compatível com os termos e permissões aplicáveis.
- A API atual aceita eventos de teste/manuais e pode analisar dados recebidos de uma fonte autorizada futura; ela não captura lives por conta própria.
- Não usar senha do TikTok, scraping de sessão, automação de conta ou mecanismos para contornar controles da plataforma.

## Fontes oficiais consultadas

- Catálogo de produtos: https://developers.tiktok.com/docs/en/get-started
- Webhook Events: https://developers.tiktok.com/docs/en/webhooks-events
- Webhook Verification: https://developers.tiktok.com/docs/en/webhooks-verification
- Data Portability API — tipos de dados (última atualização indicada: 04/08/2026): https://developers.tiktok.com/docs/en/data-portability-data-types
- Data Portability API — Get Started e ciclo de exportação: https://developers.tiktok.com/docs/en/data-portability-api-get-started
- Data Portability API — cobertura regional: https://developers.tiktok.com/products/data-portability-api/
- Data Portability API — FAQ (última atualização indicada: 22/09/2026): https://developers.tiktok.com/docs/en/data-portability-api-faq
- Data Portability API — apresentação oficial: https://developers.tiktok.com/blog/2024-introducing-tiktok-data-portability-api

A disponibilidade pode mudar; revalidar documentação, região, produtos e escopos no Developer Portal antes de iniciar qualquer integração.

## Requisitos para uma integração futura

### Integração oficial

Antes de implementar um conector oficial, o responsável pelo app deverá:

1. Registrar/validar o aplicativo no portal TikTok for Developers e concluir os requisitos de revisão/aprovação aplicáveis.
2. Identificar um produto/API oficialmente disponível que conceda explicitamente acesso aos eventos LIVE necessários (comentários, presentes, entrada/saída ou sinais de moderação em tempo real). A aprovação de Login Kit, Data Portability ou outra API não implica acesso a eventos LIVE.
3. Confirmar por escrito os escopos, limites, regiões, tipos de conta e condições de uso; obter aprovação do TikTok e consentimento/autorização do criador/parceiro.
4. Implementar OAuth/gestão de tokens apenas conforme o fluxo oficial, armazenamento seguro, rotação/revogação e tratamento de remoção de autorização.
5. Se o produto usar webhooks, implementar HTTPS público, validar `TikTok-Signature` por HMAC-SHA256 sobre `timestamp.payload` com o client secret, rejeitar timestamps antigos para reduzir replay, garantir idempotência e responder HTTP 200 rapidamente; logs nunca devem conter segredos.
6. Mapear a identidade do criador para `creator_id`, restringir o conector a criadores autorizados e manter trilha de auditoria/retention.
7. Executar testes de integração somente com ambiente/conta autorizados e registrar evidência de que os eventos realmente chegam em tempo real.

### Modo independente

- Continua **desativado** neste pacote. Não há biblioteca/cliente de eventos conectado.
- Uma futura biblioteca de terceiros exige revisão de manutenção, origem do código, permissões, segurança, privacidade, compatibilidade e termos atuais da plataforma.
- O criador/parceiro precisa autorizar expressamente o monitoramento. Não coletar senha, cookie, token de sessão nem automatizar login.
- O endpoint `authorized_connector` exige `LIVE_PROTECT_CONNECTOR_TOKEN` e restringe o `creator_id` a `LIVE_PROTECT_OWNER_CREATOR_ID` ou a um criador com parceiro ativo. Isso é uma barreira de autenticação/autorização do backend, não uma fonte de eventos.

### Dependências operacionais antes da produção

- Backend publicado em HTTPS, domínio/DNS, certificado TLS e banco persistente com backup.
- `LIVE_PROTECT_API_TOKEN` forte para administração.
- `LIVE_PROTECT_CONNECTOR_TOKEN` exclusivo para serviço conector e `LIVE_PROTECT_OWNER_CREATOR_ID` para o criador proprietário.
- Rate limiting no gateway/WAF, auditoria, política de retenção e alertas de saúde.
- Para notificações push em segundo plano: projeto Firebase, `google-services.json`, Firebase Cloud Messaging, credenciais de servidor e endpoint de envio protegido.
- Para release Android: JDK 17+, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK Platform 35, Build Tools 35.0.0 e chave de assinatura privada protegida.

**Status atual:** autenticação de parceiro e análise de eventos de teste funcionam; nenhuma integração independente ou oficial está ativa e nenhum evento real de TikTok LIVE é recebido.

## Nota de arquitetura para dados históricos

Se o TikTok aprovar Data Portability para a aplicação e para o usuário em uma região elegível, um módulo separado poderá solicitar e importar arquivos históricos de LIVE/comentários com consentimento explícito. Esse módulo deverá marcar a origem como `tiktok_data_portability`, registrar o período coberto e nunca exibir os dados como monitoramento ao vivo. A cobertura regional atual não inclui usuários do Brasil segundo a página oficial do produto.
