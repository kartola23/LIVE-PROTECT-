# LIVE PROTECT — relatório de testes 0.8.7
Data: 05/11/2026

## Testes executados nesta execução
- `python -m pytest -q`: **31 passed**.
- `python -m compileall -q backend/live_protect backend/tests`: aprovado.
- `bash -n scripts/build-release.sh scripts/check-android-env.sh`: aprovado.
- `app/src/main/AndroidManifest.xml`: XML válido.
- `.github/workflows/android-apk.yml` e `ANDROID_APK_WORKFLOW_UPLOAD.yml`: YAML válido por PyYAML.
- Verificação de ambiente Android: bloqueada por ausência de Gradle 8.9, Android SDK Platform 35, Build Tools 35.0.0, `adb`, `apksigner`, `zipalign` e `aapt`.

## Alterações 0.8.7 cobertas
- Cooldown de spam/rajada persistido em SQLite por SHA-256 da chave do padrão; os identificadores brutos não são gravados na tabela de cooldown.
- Transação `BEGIN IMMEDIATE` para evitar que workers que compartilham o mesmo arquivo SQLite liberem simultaneamente o mesmo cooldown.
- Cooldown continua ativo após recriar a instância do detector (simulação de reinício do processo).
- `RLock` protege as janelas de estado em memória durante ingestão concorrente no mesmo processo.
- Testes de regressão para persistência após reinício e ingestão concorrente.
- Rate limit de login com cinco falhas por parceiro e 30 por origem; teste de isolamento entre contas e bloqueio contra credential spraying.
- HMAC-SHA-256 para chaves de rate limit; testes confirmam que IDs/IPs não são armazenados em claro.
- `BEGIN IMMEDIATE` no contador de falhas de login; teste concorrente confirma que 12 incrementos paralelos não são perdidos.
- Android `versionCode=9`, `versionName=0.8.7`; versão do endpoint `/health` atualizada.

## Limitações e bloqueios
- Nenhuma compilação Android foi executada: Gradle e Android SDK não estão disponíveis neste runtime.
- O projeto não contém Gradle Wrapper (`gradlew`/`gradle-wrapper.jar`).
- Nenhum APK foi compilado, assinado, instalado ou validado.
- O repositório `kartola23/LIVE-PROTECT-` está acessível para leitura e os metadados indicam permissão push do usuário; contudo, a API de conteúdo recusou a gravação do workflow com HTTP 403 `Resource not accessible by integration`. A branch `LIVE-PROTECT` ainda contém apenas README e arquivo residual; o código-fonte completo ainda não foi publicado.
- O modo independente e a integração oficial TikTok continuam desativados; nenhum evento real de LIVE é recebido.
- As janelas brutas do detector continuam em memória; somente o cooldown é persistido. A persistência de cooldown requer que os workers compartilhem o mesmo banco SQLite.
