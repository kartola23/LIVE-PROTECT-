# LIVE PROTECT — revalidação diária
Data: 31/10/2026
Base: Android 0.8.2 (`versionCode` 4)

## Trabalho efetivamente realizado
- Reaberto e verificado o pacote-fonte 0.8.2; o SHA-256 do ZIP original confere com o arquivo de checksum fornecido.
- Adicionado `pytest.ini` na raiz para permitir execução dos testes do backend a partir da raiz do projeto.
- Corrigido `RELEASE_APK.md`, que ainda citava Android 0.8.1; agora descreve 0.8.2, o procedimento de build e a situação real do keystore.
- Atualizado `TEST_REPORT.md` com os resultados desta revalidação.
- Marcados os scripts de diagnóstico e build como executáveis.

## Testes executados
- `python -m pytest -q`: 23 aprovados.
- `python -m compileall -q backend/live_protect backend/tests`: aprovado.
- `bash -n scripts/build-release.sh scripts/check-android-env.sh`: aprovado.
- Parse de `AndroidManifest.xml`: XML válido.
- Integridade do ZIP de origem e SHA-256: aprovados.
- Cobertura existente inclui login e escopo de parceiro, criação/listagem/revogação, expiração e rate limit, persistência de alertas, regras de spam/rajada e rejeição de provedores LIVE não conectados.

## Estado funcional e limites
- Backend e testes automatizados estão validados neste runtime.
- O modo independente continua sem fonte de eventos conectada; não recebe comentários LIVE reais.
- A integração oficial TikTok permanece desativada até haver produto, escopos, região e aprovação que concedam explicitamente os eventos necessários.
- Polling e notificações locais dependem de o app estar ativo; push em segundo plano ainda requer FCM e serviço de envio.

## Bloqueios concretos
- JDK 21 está presente.
- Gradle 8.9, Gradle Wrapper, Android SDK Platform 35, Build Tools 35.0.0, `adb`, `apksigner`, `zipalign`, `aapt` e keystore JKS não estão acessíveis neste runtime.
- `ANDROID_SDK_ROOT` e `ANDROID_HOME` não estão definidos.
- O telefone do usuário não está conectado a este runtime; ferramentas instaladas localmente no aparelho não ficam automaticamente disponíveis aqui.
- Não foi gerado, assinado, instalado ou validado nenhum APK.

## Próximo passo
Disponibilizar um ambiente de build acessível com Gradle 8.9, SDK 35 e Build Tools 35.0.0, além do keystore do proprietário em caminho protegido; então executar `:app:assembleRelease`, `zipalign`, `apksigner verify` e, com aparelho conectado, `adb install`.
