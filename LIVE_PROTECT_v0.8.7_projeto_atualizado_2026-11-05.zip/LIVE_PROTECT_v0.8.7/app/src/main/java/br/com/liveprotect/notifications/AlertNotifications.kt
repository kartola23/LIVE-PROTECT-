package br.com.liveprotect.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import br.com.liveprotect.data.LiveAlert

object AlertNotifications {
    const val CHANNEL_ID = "live_protect_security_alerts"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Alertas de segurança",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificações de alertas encontrados pelo LIVE PROTECT"
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    fun show(context: Context, alert: LiveAlert) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("LIVE PROTECT • ${alert.severity.uppercase()}")
            .setContentText(alert.summary)
            .setStyle(Notification.BigTextStyle().bigText("${alert.summary}\n${alert.evidence}"))
            .setAutoCancel(true)
            .build()
        manager.notify(alert.id, notification)
    }
}
