package br.com.liveprotect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import br.com.liveprotect.ui.LiveProtectApp
import br.com.liveprotect.notifications.AlertNotifications

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertNotifications.createChannel(this)
        setContent { LiveProtectApp() }
    }
}
