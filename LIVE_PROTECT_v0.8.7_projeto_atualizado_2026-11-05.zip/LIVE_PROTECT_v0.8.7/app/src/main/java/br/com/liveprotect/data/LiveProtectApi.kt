package br.com.liveprotect.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

data class ApiCheckResult(val ok: Boolean, val message: String, val details: String = "")

data class ApiResult<T>(val ok: Boolean, val message: String, val data: T? = null)

data class PartnerSessionData(
    val accessToken: String,
    val expiresAt: String,
    val partnerId: String,
    val displayName: String,
    val creatorId: String,
    val role: String = "partner"
)

data class PartnerCreatedData(
    val id: String,
    val displayName: String,
    val creatorId: String,
    val accessCode: String
)

data class PartnerAdminData(
    val id: String,
    val displayName: String,
    val creatorId: String,
    val active: Boolean,
    val createdAt: String
)

data class LiveAlert(
    val id: Int,
    val liveId: String,
    val creatorId: String,
    val category: String,
    val severity: String,
    val summary: String,
    val evidence: String,
    val createdAt: String,
    val source: String
)

object LiveProtectApi {
    private const val CONNECT_TIMEOUT_MS = 7000
    private const val READ_TIMEOUT_MS = 7000

    private fun cleanBase(baseUrl: String): String? {
        val clean = baseUrl.trim().trimEnd('/')
        return try {
            val uri = URI(clean)
            val valid = uri.scheme.equals("https", ignoreCase = true) &&
                !uri.host.isNullOrBlank() &&
                uri.userInfo == null &&
                uri.query == null &&
                uri.fragment == null
            if (valid) clean else null
        } catch (_: Exception) {
            null
        }
    }

    private fun openConnection(url: String, method: String, bearer: String? = null): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            // Never forward bearer credentials through an unexpected HTTP redirect.
            instanceFollowRedirects = false
            useCaches = false
            setRequestProperty("Accept", "application/json")
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
        }
    }

    private fun responseBody(connection: HttpURLConnection): String {
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        return stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
    }

    private fun apiError(body: String, fallback: String): String {
        return try {
            val json = JSONObject(body)
            json.optString("detail").ifBlank { fallback }
        } catch (_: Exception) {
            fallback
        }
    }

    suspend fun checkHealth(baseUrl: String): ApiCheckResult = withContext(Dispatchers.IO) {
        val base = cleanBase(baseUrl)
            ?: return@withContext ApiCheckResult(false, "Informe uma URL HTTPS válida para a API.")
        var connection: HttpURLConnection? = null
        try {
            connection = openConnection("$base/health", "GET")
            val code = connection.responseCode
            val body = responseBody(connection)
            if (code in 200..299) ApiCheckResult(true, "Servidor conectado", body.take(500))
            else ApiCheckResult(false, "Servidor respondeu HTTP $code", apiError(body, body.take(300)))
        } catch (e: Exception) {
            ApiCheckResult(false, "Não foi possível conectar", e.message ?: "Erro de rede")
        } finally {
            connection?.disconnect()
        }
    }

    suspend fun partnerLogin(baseUrl: String, partnerId: String, accessCode: String): ApiResult<PartnerSessionData> =
        withContext(Dispatchers.IO) {
            val base = cleanBase(baseUrl)
                ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida para a API.")
            var connection: HttpURLConnection? = null
            try {
                connection = openConnection("$base/auth/partner-login", "POST").apply {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject()
                    .put("partner_id", partnerId.trim())
                    .put("access_code", accessCode.trim())
                connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val body = responseBody(connection)
                if (code !in 200..299) return@withContext ApiResult(false, apiError(body, "Falha no login (HTTP $code)."))
                val json = JSONObject(body)
                val partner = json.getJSONObject("partner")
                val session = PartnerSessionData(
                    accessToken = json.getString("access_token"),
                    expiresAt = json.getString("expires_at"),
                    partnerId = partner.getString("id"),
                    displayName = partner.getString("display_name"),
                    creatorId = partner.getString("creator_id")
                )
                ApiResult(true, "Acesso autorizado", session)
            } catch (e: Exception) {
                ApiResult(false, "Não foi possível concluir o login: ${e.message ?: "erro de rede"}")
            } finally {
                connection?.disconnect()
            }
        }

    suspend fun verifyOwner(baseUrl: String, adminToken: String, creatorId: String): ApiResult<Boolean> =
        withContext(Dispatchers.IO) {
            val base = cleanBase(baseUrl)
                ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida para a API.")
            if (adminToken.isBlank() || creatorId.isBlank()) {
                return@withContext ApiResult(false, "Informe o token administrativo e o ID do criador.")
            }
            var connection: HttpURLConnection? = null
            try {
                val encodedCreator = URLEncoder.encode(creatorId.trim(), "UTF-8")
                connection = openConnection("$base/owner/verify?creator_id=$encodedCreator", "GET", adminToken)
                val code = connection.responseCode
                val body = responseBody(connection)
                if (code !in 200..299) {
                    ApiResult(false, apiError(body, "Acesso administrativo recusado (HTTP $code)."))
                } else {
                    ApiResult(true, "Proprietário confirmado", true)
                }
            } catch (e: Exception) {
                ApiResult(false, "Não foi possível validar o administrador: ${e.message ?: "erro de rede"}")
            } finally {
                connection?.disconnect()
            }
        }

    suspend fun createPartner(
        baseUrl: String,
        adminToken: String,
        displayName: String,
        creatorId: String
    ): ApiResult<PartnerCreatedData> = withContext(Dispatchers.IO) {
        val base = cleanBase(baseUrl)
            ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida para a API.")
        if (adminToken.isBlank()) return@withContext ApiResult(false, "Informe o token administrativo.")
        var connection: HttpURLConnection? = null
        try {
            connection = openConnection("$base/partners", "POST", adminToken).apply {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val payload = JSONObject()
                .put("display_name", displayName.trim())
                .put("creator_id", creatorId.trim())
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val body = responseBody(connection)
            if (code !in 200..299) return@withContext ApiResult(false, apiError(body, "Falha ao criar parceiro (HTTP $code)."))
            val json = JSONObject(body)
            ApiResult(
                true,
                "Parceiro criado. Guarde o código: ele só é exibido nesta resposta.",
                PartnerCreatedData(
                    id = json.getString("id"),
                    displayName = json.getString("display_name"),
                    creatorId = json.getString("creator_id"),
                    accessCode = json.getString("access_code")
                )
            )
        } catch (e: Exception) {
            ApiResult(false, "Não foi possível criar o parceiro: ${e.message ?: "erro de rede"}")
        } finally {
            connection?.disconnect()
        }
    }

    suspend fun listPartners(baseUrl: String, adminToken: String): ApiResult<List<PartnerAdminData>> =
        withContext(Dispatchers.IO) {
            val base = cleanBase(baseUrl)
                ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida.")
            if (adminToken.isBlank()) return@withContext ApiResult(false, "Token administrativo ausente.")
            var connection: HttpURLConnection? = null
            try {
                connection = openConnection("$base/partners", "GET", adminToken)
                val code = connection.responseCode
                val body = responseBody(connection)
                if (code !in 200..299) {
                    return@withContext ApiResult(false, apiError(body, "Falha ao listar parceiros (HTTP $code)."))
                }
                val json = JSONArray(body)
                val partners = buildList {
                    for (index in 0 until json.length()) {
                        val item = json.getJSONObject(index)
                        add(
                            PartnerAdminData(
                                id = item.getString("id"),
                                displayName = item.getString("display_name"),
                                creatorId = item.getString("creator_id"),
                                active = item.optBoolean("active", false),
                                createdAt = item.optString("created_at")
                            )
                        )
                    }
                }
                ApiResult(true, "${partners.size} parceiro(s) cadastrado(s)", partners)
            } catch (e: Exception) {
                ApiResult(false, "Não foi possível listar parceiros: ${e.message ?: "erro de rede"}")
            } finally {
                connection?.disconnect()
            }
        }

    suspend fun revokePartner(baseUrl: String, adminToken: String, partnerId: String): ApiResult<Boolean> =
        withContext(Dispatchers.IO) {
            val base = cleanBase(baseUrl)
                ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida.")
            if (adminToken.isBlank() || partnerId.isBlank()) {
                return@withContext ApiResult(false, "Token administrativo e ID do parceiro são obrigatórios.")
            }
            var connection: HttpURLConnection? = null
            try {
                val encodedId = URLEncoder.encode(partnerId.trim(), "UTF-8")
                connection = openConnection("$base/partners/$encodedId/revoke", "POST", adminToken).apply {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                connection.outputStream.use { it.write("{}".toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val body = responseBody(connection)
                if (code !in 200..299) {
                    return@withContext ApiResult(false, apiError(body, "Falha ao revogar parceiro (HTTP $code)."))
                }
                ApiResult(true, "Acesso do parceiro revogado.", true)
            } catch (e: Exception) {
                ApiResult(false, "Não foi possível revogar o parceiro: ${e.message ?: "erro de rede"}")
            } finally {
                connection?.disconnect()
            }
        }

    suspend fun fetchAlerts(baseUrl: String, accessToken: String, creatorId: String): ApiResult<List<LiveAlert>> =
        withContext(Dispatchers.IO) {
            val base = cleanBase(baseUrl)
                ?: return@withContext ApiResult(false, "Informe uma URL HTTPS válida.")
            var connection: HttpURLConnection? = null
            try {
                val encodedCreator = URLEncoder.encode(creatorId, "UTF-8")
                connection = openConnection("$base/alerts?creator_id=$encodedCreator&limit=100", "GET", accessToken)
                val code = connection.responseCode
                val body = responseBody(connection)
                if (code !in 200..299) return@withContext ApiResult(false, apiError(body, "Falha ao consultar alertas (HTTP $code)."))
                val json = JSONArray(body)
                val alerts = buildList {
                    for (index in 0 until json.length()) {
                        val item = json.getJSONObject(index)
                        add(
                            LiveAlert(
                                id = item.getInt("id"),
                                liveId = item.optString("live_id"),
                                creatorId = item.optString("creator_id"),
                                category = item.optString("category"),
                                severity = item.optString("severity"),
                                summary = item.optString("summary"),
                                evidence = item.optString("evidence"),
                                createdAt = item.optString("created_at"),
                                source = item.optString("source")
                            )
                        )
                    }
                }
                ApiResult(true, "${alerts.size} alerta(s) consultado(s)", alerts)
            } catch (e: Exception) {
                ApiResult(false, "Não foi possível consultar alertas: ${e.message ?: "erro de rede"}")
            } finally {
                connection?.disconnect()
            }
        }
}
