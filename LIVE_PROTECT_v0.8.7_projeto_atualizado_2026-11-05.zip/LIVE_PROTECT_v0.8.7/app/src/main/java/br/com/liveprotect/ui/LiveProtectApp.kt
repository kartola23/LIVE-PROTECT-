package br.com.liveprotect.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.liveprotect.data.AppSettings
import br.com.liveprotect.data.LiveAlert
import br.com.liveprotect.data.LiveProtectApi
import br.com.liveprotect.data.PartnerSessionData
import br.com.liveprotect.data.PartnerCreatedData
import br.com.liveprotect.data.PartnerAdminData
import br.com.liveprotect.data.SecureSessionStore
import br.com.liveprotect.notifications.AlertNotifications
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFAAA39A)
private val White = Color(0xFFF5F1E8)

@Composable
fun LiveProtectApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var baseUrl by remember { mutableStateOf(AppSettings.baseUrl(context)) }
    var session by remember { mutableStateOf(SecureSessionStore.load(context)) }
    var selected by remember { mutableStateOf("Início") }
    var alerts by remember { mutableStateOf<List<LiveAlert>>(emptyList()) }
    var status by remember { mutableStateOf("Aguardando autenticação.") }
    var busy by remember { mutableStateOf(false) }
    var notificationsEnabled by remember { mutableStateOf(AppSettings.notificationsEnabled(context)) }
    var seenAlertIds by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var hasLoadedAlerts by remember { mutableStateOf(false) }
    var createdPartner by remember { mutableStateOf<PartnerCreatedData?>(null) }
    var partners by remember { mutableStateOf<List<PartnerAdminData>>(emptyList()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsEnabled = granted
        AppSettings.setNotificationsEnabled(context, granted)
        status = if (granted) "Notificações ativadas." else "Permissão de notificações não concedida."
    }

    fun refreshAlerts() {
        val current = session ?: return
        if (busy) return
        busy = true
        scope.launch {
            val result = LiveProtectApi.fetchAlerts(baseUrl, current.accessToken, current.creatorId)
            if (result.ok && result.data != null) {
                val latest = result.data
                val newAlerts = if (hasLoadedAlerts) latest.filter { it.id !in seenAlertIds } else emptyList()
                if (notificationsEnabled) newAlerts.forEach { AlertNotifications.show(context, it) }
                seenAlertIds = latest.map { it.id }.toSet()
                alerts = latest
                hasLoadedAlerts = true
                status = result.message
            } else {
                status = result.message
                if (result.message.contains("Sessão inválida", true) || result.message.contains("expirada", true)) {
                    SecureSessionStore.clear(context)
                    session = null
                    selected = "Início"
                }
            }
            busy = false
        }
    }

    fun refreshPartners() {
        val current = session ?: return
        if (current.role != "owner" || busy) return
        busy = true
        scope.launch {
            val result = LiveProtectApi.listPartners(baseUrl, current.accessToken)
            if (result.ok && result.data != null) {
                partners = result.data
                status = result.message
            } else {
                status = result.message
            }
            busy = false
        }
    }

    fun revokePartner(partnerId: String) {
        val current = session ?: return
        if (current.role != "owner" || busy) return
        busy = true
        scope.launch {
            val result = LiveProtectApi.revokePartner(baseUrl, current.accessToken, partnerId)
            status = result.message
            if (result.ok) {
                val refreshed = LiveProtectApi.listPartners(baseUrl, current.accessToken)
                if (refreshed.ok && refreshed.data != null) partners = refreshed.data
            }
            busy = false
        }
    }

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            notificationsEnabled = true
            AppSettings.setNotificationsEnabled(context, true)
            status = "Notificações ativadas."
        }
    }

    LaunchedEffect(session?.accessToken) {
        if (session != null) {
            refreshAlerts()
            // Polling while the app process is active. Background delivery still requires FCM.
            while (true) {
                delay(60_000)
                refreshAlerts()
            }
        }
    }

    LaunchedEffect(selected, session?.accessToken) {
        if (selected == "Parceiro" && session?.role == "owner") refreshPartners()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Black,
            surface = Panel,
            onPrimary = Black,
            onBackground = White,
            onSurface = White
        )
    ) {
        if (session == null) {
            LoginScreen(
                baseUrl = baseUrl,
                onBaseUrlChange = { baseUrl = it },
                busy = busy,
                status = status,
                createdPartner = createdPartner,
                onCreatePartner = { adminToken, displayName, creatorId ->
                    scope.launch {
                        busy = true
                        AppSettings.saveBaseUrl(context, baseUrl)
                        val result = LiveProtectApi.createPartner(baseUrl, adminToken, displayName, creatorId)
                        createdPartner = result.data
                        status = result.message
                        busy = false
                    }
                },
                onOwnerLogin = { adminToken, creatorId ->
                    scope.launch {
                        busy = true
                        AppSettings.saveBaseUrl(context, baseUrl)
                        val result = LiveProtectApi.verifyOwner(baseUrl, adminToken, creatorId)
                        if (result.ok && result.data == true) {
                            SecureSessionStore.clear(context)
                            session = PartnerSessionData(
                                accessToken = adminToken,
                                expiresAt = "Somente enquanto o aplicativo estiver aberto",
                                partnerId = "owner",
                                displayName = "Administrador",
                                creatorId = creatorId.trim(),
                                role = "owner"
                            )
                            selected = "Início"
                            status = "Proprietário confirmado. O token ficará apenas na memória do aplicativo."
                            hasLoadedAlerts = false
                            seenAlertIds = emptySet()
                        } else {
                            status = result.message
                        }
                        busy = false
                    }
                },
                onLogin = { partnerId, accessCode ->
                    scope.launch {
                        busy = true
                        AppSettings.saveBaseUrl(context, baseUrl)
                        val result = LiveProtectApi.partnerLogin(baseUrl, partnerId, accessCode)
                        if (result.ok && result.data != null) {
                            if (SecureSessionStore.save(context, result.data)) {
                                session = result.data
                                selected = "Início"
                                status = "Acesso autorizado."
                                hasLoadedAlerts = false
                                seenAlertIds = emptySet()
                            } else {
                                status = "Login aceito, mas não foi possível proteger a sessão neste aparelho."
                            }
                        } else {
                            status = result.message
                        }
                        busy = false
                    }
                }
            )
        } else {
            val currentSession = session!!
            Scaffold(
                containerColor = Black,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Gold) {
                        val tabs = listOf("Início", "Alertas", "Parceiro", "Ajustes")
                        val icons = listOf(Icons.Default.Shield, Icons.Default.Notifications, Icons.Default.People, Icons.Default.Settings)
                        tabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selected == tab,
                                onClick = { selected = tab },
                                icon = { Icon(icons[index], contentDescription = tab) },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold,
                                    selectedTextColor = Gold,
                                    indicatorColor = Color(0xFF3A2D16),
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (selected) {
                        "Início" -> DashboardScreen(
                            session = currentSession,
                            alertCount = alerts.size,
                            status = status,
                            busy = busy,
                            onRefresh = ::refreshAlerts,
                            onAlerts = { selected = "Alertas" }
                        )
                        "Alertas" -> AlertsScreen(alerts, status, busy, ::refreshAlerts)
                        "Parceiro" -> PartnerScreen(
                            session = currentSession,
                            partners = partners,
                            busy = busy,
                            status = status,
                            onRefreshPartners = ::refreshPartners,
                            onRevokePartner = ::revokePartner,
                            onLogout = {
                                SecureSessionStore.clear(context)
                                session = null
                                alerts = emptyList()
                                partners = emptyList()
                                selected = "Início"
                                status = "Sessão encerrada."
                            }
                        )
                        else -> SettingsScreen(
                            baseUrl = baseUrl,
                            onBaseUrlChange = { baseUrl = it },
                            notificationsEnabled = notificationsEnabled,
                            status = status,
                            onSaveUrl = {
                                AppSettings.saveBaseUrl(context, baseUrl)
                                status = "Endereço da API salvo."
                                if (session != null) refreshAlerts()
                            },
                            onTestServer = {
                                scope.launch {
                                    busy = true
                                    val check = LiveProtectApi.checkHealth(baseUrl)
                                    status = if (check.ok) "${check.message}: ${check.details}" else "${check.message}: ${check.details}"
                                    busy = false
                                }
                            },
                            onNotificationsChanged = { enabled ->
                                if (enabled) requestNotifications() else {
                                    notificationsEnabled = false
                                    AppSettings.setNotificationsEnabled(context, false)
                                    status = "Notificações desativadas."
                                }
                            },
                            busy = busy
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun GoldCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp), content = content)
    }
}

@Composable
private fun LoginScreen(
    baseUrl: String,
    onBaseUrlChange: (String) -> Unit,
    busy: Boolean,
    status: String,
    createdPartner: PartnerCreatedData?,
    onCreatePartner: (String, String, String) -> Unit,
    onOwnerLogin: (String, String) -> Unit,
    onLogin: (String, String) -> Unit
) {
    var partnerId by remember { mutableStateOf("") }
    var accessCode by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("partner") }
    var adminToken by remember { mutableStateOf("") }
    var newPartnerName by remember { mutableStateOf("") }
    var creatorId by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("LIVE PROTECT", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
                Text("CENTRAL DE SEGURANÇA", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
        }
        PageTitle(
            when (mode) { "owner" -> "Entrar como administrador"; "create" -> "Criar acesso de parceiro"; else -> "Entrar como parceiro" },
            when (mode) { "owner" -> "Valide o token administrativo e o ID do criador proprietário."; "create" -> "Emita um código individual para um parceiro autorizado."; else -> "Use o código de acesso emitido pelo administrador." }
        )
        GoldCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { mode = "partner" }) { Text("PARCEIRO", color = if (mode == "partner") Gold else Muted) }
                TextButton(onClick = { mode = "owner" }) { Text("ADMIN", color = if (mode == "owner") Gold else Muted) }
                TextButton(onClick = { mode = "create" }) { Text("CRIAR", color = if (mode == "create") Gold else Muted) }
            }
            OutlinedTextField(
                value = baseUrl,
                onValueChange = onBaseUrlChange,
                label = { Text("URL HTTPS da API") },
                placeholder = { Text("https://seu-servidor.com") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            if (mode == "partner") {
                OutlinedTextField(
                    value = partnerId,
                    onValueChange = { partnerId = it },
                    label = { Text("ID do parceiro") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = accessCode,
                    onValueChange = { accessCode = it },
                    label = { Text("Código de acesso") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { onLogin(partnerId, accessCode) },
                    enabled = !busy && baseUrl.isNotBlank() && partnerId.isNotBlank() && accessCode.length >= 20,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                ) { Text(if (busy) "AGUARDE..." else "ENTRAR") }
            } else {
                OutlinedTextField(
                    value = adminToken,
                    onValueChange = { adminToken = it },
                    label = { Text("Token administrativo do servidor") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = creatorId,
                    onValueChange = { creatorId = it },
                    label = { Text("ID do criador autorizado (não @usuário)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                if (mode == "create") {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPartnerName,
                        onValueChange = { newPartnerName = it },
                        label = { Text("Nome do parceiro") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            onCreatePartner(adminToken, newPartnerName, creatorId)
                            adminToken = ""
                        },
                        enabled = !busy && adminToken.isNotBlank() && newPartnerName.trim().length >= 2 && creatorId.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                    ) { Text(if (busy) "AGUARDE..." else "CRIAR ACESSO") }
                    Text("O token administrativo não é salvo no aparelho.", color = Muted, fontSize = 10.sp)
                    if (createdPartner != null) {
                        Spacer(Modifier.height(12.dp))
                        Text("ACESSO CRIADO — GUARDE AGORA", color = Gold, fontWeight = FontWeight.Bold)
                        Text("ID: ${createdPartner.id}", color = Muted, fontSize = 11.sp)
                        Text("Código de acesso (exibido uma única vez):", color = Muted, fontSize = 11.sp)
                        SelectionContainer { Text(createdPartner.accessCode, color = White, fontWeight = FontWeight.Bold) }
                        Text("Envie o ID e o código ao parceiro por canal seguro. O código não é armazenado em texto no servidor.", color = Muted, fontSize = 10.sp)
                    }
                } else {
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            onOwnerLogin(adminToken, creatorId)
                            adminToken = ""
                        },
                        enabled = !busy && adminToken.isNotBlank() && creatorId.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                    ) { Text(if (busy) "VALIDANDO..." else "ENTRAR COMO ADMINISTRADOR") }
                    Text("O token não é gravado no armazenamento do app; a sessão administrativa termina quando o app é fechado.", color = Muted, fontSize = 10.sp)
                }
            }
        }
        Text(status, color = Muted, fontSize = 12.sp)
        Text(
            when (mode) {
                "create" -> "A criação exige o token administrativo configurado no servidor. Nunca compartilhe esse token com parceiros."
                "owner" -> "O ID precisa coincidir com LIVE_PROTECT_OWNER_CREATOR_ID configurado no servidor."
                else -> "Não informe sua senha do TikTok. O acesso usa somente o ID e o código de parceiro emitido pelo administrador."
            },
            color = Gold,
            fontSize = 11.sp
        )
        Text(
            "O login não conecta uma live automaticamente. Uma fonte autorizada de eventos ainda precisa ser configurada no servidor.",
            color = Muted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun DashboardScreen(
    session: PartnerSessionData,
    alertCount: Int,
    status: String,
    busy: Boolean,
    onRefresh: () -> Unit,
    onAlerts: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("LIVE PROTECT", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text("CENTRAL DE SEGURANÇA", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
        }
        PageTitle("Painel de proteção", "Olá, ${session.displayName}.")
        GoldCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (session.role == "owner") "Acesso administrativo confirmado" else "Conta de parceiro autorizada", color = White, fontWeight = FontWeight.Bold)
                    Text("Criador vinculado: ${session.creatorId}", color = Muted, fontSize = 11.sp)
                }
                Surface(color = Color(0xFF3A2D16), shape = RoundedCornerShape(30.dp)) {
                    Text("LOGIN OK", color = Gold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (session.role == "owner") "O token administrativo fica somente na memória enquanto o app estiver aberto." else "A sessão de parceiro é armazenada criptografada no Android e expira conforme o servidor.",
                color = Muted,
                fontSize = 11.sp
            )
        }
        GoldCard {
            Text("Monitoramento de LIVE", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Nenhuma fonte de eventos LIVE está conectada. O aplicativo não afirma receber comentários reais até que um conector autorizado esteja ativo.", color = Gold, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onRefresh, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(6.dp))
                Text(if (busy) "ATUALIZANDO..." else "ATUALIZAR ALERTAS")
            }
            Text(status, color = Muted, fontSize = 11.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(alertCount.toString(), "Alertas recebidos", Modifier.weight(1f))
            MetricCard(if (session.role == "owner") "Memória" else "12 h", if (session.role == "owner") "Token não persistido" else "Validade da sessão", Modifier.weight(1f))
        }
        GoldCard {
            Text("Central de ocorrências", color = White, fontWeight = FontWeight.Bold)
            Text("Alertas recebidos da API: $alertCount", color = Muted, fontSize = 12.sp)
            TextButton(onClick = onAlerts) { Text("VER ALERTAS", color = Gold) }
        }
    }
}

@Composable
private fun MetricCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(value, color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AlertsScreen(alerts: List<LiveAlert>, status: String, busy: Boolean, onRefresh: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PageTitle("Alertas", "Ocorrências retornadas pelo servidor.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh, enabled = !busy) { Icon(Icons.Default.Refresh, "Atualizar", tint = Gold) }
        }
        if (alerts.isEmpty()) {
            GoldCard {
                Icon(Icons.Default.Notifications, null, tint = Gold, modifier = Modifier.size(30.dp))
                Spacer(Modifier.height(8.dp))
                Text("Nenhum alerta recebido", color = White, fontWeight = FontWeight.Bold)
                Text("Atualize a lista. Alertas de teste e de conectores autorizados serão identificados pela origem.", color = Muted, fontSize = 12.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(alerts, key = { it.id }) { alert -> AlertCard(alert) }
            }
        }
    }
}

@Composable
private fun AlertCard(alert: LiveAlert) {
    GoldCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(alert.severity.uppercase(), color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            Text(if (alert.source == "authorized_connector") "CONECTOR AUTORIZADO" else "TESTE MANUAL", color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(alert.summary, color = White, fontWeight = FontWeight.Bold)
        Text("Categoria: ${alert.category} • Live: ${alert.liveId}", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Text(alert.evidence, color = Muted, fontSize = 12.sp)
        Text(alert.createdAt, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun PartnerScreen(
    session: PartnerSessionData,
    partners: List<PartnerAdminData>,
    busy: Boolean,
    status: String,
    onRefreshPartners: () -> Unit,
    onRevokePartner: (String) -> Unit,
    onLogout: () -> Unit
) {
    var partnerToRevoke by remember { mutableStateOf<PartnerAdminData?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageTitle(if (session.role == "owner") "Acesso do proprietário" else "Acesso do parceiro", "Permissões vinculadas a esta sessão.")
        GoldCard {
            Text(session.displayName, color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (session.role == "owner") "Perfil: proprietário" else "ID do parceiro: ${session.partnerId}", color = Muted, fontSize = 11.sp)
            Text("Criador autorizado: ${session.creatorId}", color = Muted, fontSize = 11.sp)
            Text(if (session.role == "owner") "Token mantido somente na memória enquanto o app estiver aberto." else "Expira em: ${session.expiresAt}", color = Muted, fontSize = 11.sp)
        }
        if (session.role == "owner") {
            GoldCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Parceiros autorizados", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = onRefreshPartners, enabled = !busy) {
                        Icon(Icons.Default.Refresh, "Atualizar parceiros", tint = Gold)
                    }
                }
                Text(status, color = Muted, fontSize = 11.sp)
                if (partners.isEmpty()) {
                    Text("Nenhum parceiro listado ou a lista ainda não foi carregada.", color = Muted, fontSize = 12.sp)
                }
            }
            partners.forEach { partner ->
                GoldCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(partner.displayName, color = White, fontWeight = FontWeight.Bold)
                            Text("ID: ${partner.id}", color = Muted, fontSize = 10.sp)
                            Text("Criador: ${partner.creatorId}", color = Muted, fontSize = 10.sp)
                        }
                        Text(if (partner.active) "ATIVO" else "REVOGADO",
                            color = if (partner.active) Gold else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    if (partner.active) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { partnerToRevoke = partner },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("REVOGAR ACESSO", color = Gold) }
                    }
                }
            }
        }
        GoldCard {
            Text("Escopo de segurança", color = White, fontWeight = FontWeight.Bold)
            Text("Esta sessão consulta alertas somente para o criador vinculado. Ela não concede acesso à conta TikTok nem cria uma conexão LIVE.", color = Muted, fontSize = 12.sp)
        }
        Button(onClick = onLogout, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) {
            Icon(Icons.Default.Logout, null)
            Spacer(Modifier.width(8.dp))
            Text("SAIR DA CONTA")
        }
    }
    partnerToRevoke?.let { target ->
        AlertDialog(
            onDismissRequest = { partnerToRevoke = null },
            title = { Text("Revogar acesso do parceiro?") },
            text = { Text("O acesso de ${target.displayName} será desativado e as sessões atuais serão invalidadas.") },
            confirmButton = {
                TextButton(onClick = {
                    onRevokePartner(target.id)
                    partnerToRevoke = null
                }) { Text("REVOGAR", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { partnerToRevoke = null }) { Text("CANCELAR", color = Muted) }
            },
            containerColor = Panel,
            titleContentColor = White,
            textContentColor = Muted
        )
    }
}

@Composable
private fun SettingsScreen(
    baseUrl: String,
    onBaseUrlChange: (String) -> Unit,
    notificationsEnabled: Boolean,
    status: String,
    onSaveUrl: () -> Unit,
    onTestServer: () -> Unit,
    onNotificationsChanged: (Boolean) -> Unit,
    busy: Boolean
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        PageTitle("Ajustes", "Servidor, notificações e integrações.")
        GoldCard {
            Text("Conexão com servidor", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = baseUrl,
                onValueChange = onBaseUrlChange,
                label = { Text("URL base da API") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSaveUrl, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("SALVAR") }
                OutlinedButton(onClick = onTestServer, enabled = !busy) { Text("TESTAR API", color = Gold) }
            }
            Text(status, color = Muted, fontSize = 11.sp)
            Text("Em produção, use HTTPS. O servidor ainda precisa estar publicado e configurado.", color = Muted, fontSize = 10.sp)
        }
        GoldCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Notificações locais", color = White, fontWeight = FontWeight.Bold)
                    Text("Avisos quando uma atualização manual encontrar novos alertas.", color = Muted, fontSize = 11.sp)
                }
                Switch(checked = notificationsEnabled, onCheckedChange = onNotificationsChanged)
            }
            Text("Avisos em segundo plano exigem uma etapa futura com Firebase Cloud Messaging (FCM) e servidor de envio.", color = Gold, fontSize = 11.sp)
        }
        GoldCard {
            Text("Integração TikTok LIVE", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Modo independente: sem cliente de eventos conectado nesta versão. Integração oficial: depende de produto, escopos e aprovação do TikTok que incluam os eventos LIVE necessários.", color = Muted, fontSize = 12.sp)
            Text("Não informe senha do TikTok e não use scraping de sessão.", color = Gold, fontSize = 11.sp)
        }
        GoldCard {
            Text("Sobre o aplicativo", color = White, fontWeight = FontWeight.Bold)
            Text("LIVE PROTECT • versão 0.8.7", color = Muted, fontSize = 12.sp)
        }
    }
}
