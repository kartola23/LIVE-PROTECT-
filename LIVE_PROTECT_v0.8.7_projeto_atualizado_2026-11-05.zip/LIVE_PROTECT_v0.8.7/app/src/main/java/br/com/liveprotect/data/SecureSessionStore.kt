package br.com.liveprotect.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

object SecureSessionStore {
    private const val PREFS = "live_protect_secure_session"
    private const val SESSION_KEY = "encrypted_session"
    private const val KEY_ALIAS = "liveprotect_session_aes_v1"
    private const val IV_LENGTH = 12

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun save(context: Context, session: PartnerSessionData): Boolean {
        return try {
            val json = JSONObject()
                .put("accessToken", session.accessToken)
                .put("expiresAt", session.expiresAt)
                .put("partnerId", session.partnerId)
                .put("displayName", session.displayName)
                .put("creatorId", session.creatorId)
                .put("role", session.role)
                .toString()
                .toByteArray(Charsets.UTF_8)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())
            val encrypted = cipher.doFinal(json)
            val packed = cipher.iv + encrypted
            val encoded = Base64.encodeToString(packed, Base64.NO_WRAP)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(SESSION_KEY, encoded).apply()
            true
        } catch (_: Exception) {
            clear(context)
            false
        }
    }

    fun load(context: Context): PartnerSessionData? {
        val encoded = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(SESSION_KEY, null) ?: return null
        return try {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > IV_LENGTH)
            val iv = packed.copyOfRange(0, IV_LENGTH)
            val ciphertext = packed.copyOfRange(IV_LENGTH, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            val json = JSONObject(String(cipher.doFinal(ciphertext), Charsets.UTF_8))
            val expiresAt = json.getString("expiresAt")
            if (!Instant.parse(expiresAt).isAfter(Instant.now())) {
                clear(context)
                return null
            }
            PartnerSessionData(
                accessToken = json.getString("accessToken"),
                expiresAt = expiresAt,
                partnerId = json.getString("partnerId"),
                displayName = json.getString("displayName"),
                creatorId = json.getString("creatorId"),
                role = json.optString("role", "partner")
            )
        } catch (_: Exception) {
            clear(context)
            null
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(SESSION_KEY).apply()
        try {
            KeyStore.getInstance("AndroidKeyStore").apply {
                load(null)
                if (containsAlias(KEY_ALIAS)) deleteEntry(KEY_ALIAS)
            }
        } catch (_: Exception) {
            // The encrypted preference is already removed; a later login can retry key creation.
        }
    }
}

object AppSettings {
    private const val PREFS = "live_protect_settings"
    private const val BASE_URL = "api_base_url"
    private const val NOTIFICATIONS = "notifications_enabled"

    fun baseUrl(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(BASE_URL, "https://api.seu-dominio.com") ?: "https://api.seu-dominio.com"

    fun saveBaseUrl(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BASE_URL, value.trim()).apply()
    }

    fun notificationsEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean(NOTIFICATIONS, false)

    fun setNotificationsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(NOTIFICATIONS, enabled).apply()
    }
}
