plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "br.com.liveprotect"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.liveprotect"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.8.7"
    }

    signingConfigs {
        create("release") {
            val storePath = System.getenv("LP_STORE_FILE")
            val storePass = System.getenv("LP_STORE_PASSWORD")
            val keyAliasValue = System.getenv("LP_KEY_ALIAS")
            val keyPass = System.getenv("LP_KEY_PASSWORD")
            if (!storePath.isNullOrBlank()) storeFile = file(storePath)
            if (!storePass.isNullOrBlank()) storePassword = storePass
            if (!keyAliasValue.isNullOrBlank()) keyAlias = keyAliasValue
            if (!keyPass.isNullOrBlank()) keyPassword = keyPass
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            val hasSigning = !System.getenv("LP_STORE_FILE").isNullOrBlank() &&
                !System.getenv("LP_STORE_PASSWORD").isNullOrBlank() &&
                !System.getenv("LP_KEY_ALIAS").isNullOrBlank() &&
                !System.getenv("LP_KEY_PASSWORD").isNullOrBlank()
            signingConfig = if (hasSigning) signingConfigs.getByName("release") else null
        }
    }
    buildFeatures { compose = true }
}
dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
