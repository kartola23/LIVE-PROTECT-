# LIVE PROTECT — preparação de APK direto

Versão Android: **0.8.7** (`versionCode` 9). Este pacote contém o código-fonte; **não contém APK compilado**.

## Ferramentas exigidas
- JDK 17 ou superior (JDK 21 está presente no runtime de validação usado em 01/11/2026).
- Gradle 8.9. O repositório ainda não inclui `gradlew` nem `gradle-wrapper.jar`.
- Android Gradle Plugin 8.7.3 e Kotlin 2.0.21 (declarados no projeto).
- Android SDK Platform 35 e Android Build Tools 35.0.0 (`apksigner`, `zipalign` e `aapt`).
- `adb`/Android Platform Tools e aparelho ou emulador para validar a instalação física.

## Diagnóstico e testes
Na raiz do projeto:

```bash
bash scripts/check-android-env.sh
python -m pytest -q
python -m compileall -q backend/live_protect backend/tests
bash -n scripts/build-release.sh scripts/check-android-env.sh
```

O `pytest.ini` na raiz configura o caminho de importação do backend para que os testes possam ser executados sem mudar de diretório.

## Gerar e validar o APK
1. Instale Android Studio estável ou disponibilize JDK 17+, Gradle 8.9 e Android SDK.
2. No SDK Manager, aceite as licenças e instale `platform-tools`, `platforms;android-35` e `build-tools;35.0.0`.
3. Defina `ANDROID_SDK_ROOT` (ou `ANDROID_HOME`) para a pasta real do SDK.
4. Disponibilize o keystore release do proprietário em um caminho local protegido. **O arquivo JKS não está incluído neste pacote e não foi localizado no runtime de validação.**
5. Configure `LP_STORE_FILE`, `LP_STORE_PASSWORD`, `LP_KEY_ALIAS` e `LP_KEY_PASSWORD` no ambiente local protegido. Não coloque senhas em arquivos do projeto, histórico do terminal, logs ou mensagens.
6. Na raiz do projeto, execute:

```bash
bash scripts/build-release.sh
```

O script exige Gradle 8.9 e as ferramentas do SDK 35.0.0; executa `:app:assembleRelease`, verifica alinhamento com `zipalign`, assinatura com `apksigner` e identidade do pacote com `aapt`. O APK esperado é `app/build/outputs/apk/release/app-release.apk`.

A verificação do APK não comprova instalação. Para teste físico, use um dispositivo conectado e `adb install` após confirmar o pacote e a assinatura.

## Funcionalidades Android 0.8.7
- Login administrativo e login de parceiro.
- Criação, listagem e revogação de parceiros na interface do proprietário.
- Revogação invalida as sessões do parceiro no backend.
- Sessões de parceiros protegidas com AES-GCM via Android Keystore.
- URL da API exige HTTPS e rejeita userinfo, query e fragmento; redirecionamentos automáticos e cache das chamadas autenticadas ficam desativados.
- Consulta periódica de alertas a cada 60 segundos enquanto o processo do app está ativo.
- Notificações locais para alertas novos detectados pela consulta. Push em segundo plano depende de FCM e serviço de envio externo.

## Limitações e bloqueios conhecidos
- Na verificação de ambiente de 04/11/2026, JDK 21 está presente, mas Gradle 8.9, Gradle Wrapper, Android SDK Platform 35, Build Tools 35.0.0, `adb`, `apksigner`, `zipalign` e `aapt` continuam ausentes.
- O backend precisa ser publicado em HTTPS e configurado com tokens próprios antes do uso remoto.
- Modo independente e integração oficial TikTok estão desativados; nenhuma fonte real de eventos LIVE está conectada.
- Push em segundo plano exige FCM, `google-services.json`, credenciais de servidor e endpoint de envio protegido.
- Este pacote não contém APK. Nenhum APK foi compilado, assinado, instalado ou validado nesta execução. O workflow de CI também está preparado, mas ainda depende de o projeto estar em um repositório GitHub acessível e de uma execução concluída com sucesso.


## Alterações da versão 0.8.7
- O cooldown de padrões antifraude (spam/rajada) é persistido em SQLite por hash da chave do padrão, mantendo a janela de 60 segundos após reinício do processo/API.
- O registro não armazena diretamente creator_id, live_id ou user_id na tabela de cooldown.
- O acesso ao registro é serializado com `BEGIN IMMEDIATE` para reduzir duplicações entre workers que compartilham o mesmo SQLite.
- `RLock` protege as janelas de estado do detector contra atualizações concorrentes no mesmo processo.
- O histórico bruto de comentários usado para calcular padrões continua em memória; esta alteração persiste somente a janela de cooldown, não o stream de eventos.
