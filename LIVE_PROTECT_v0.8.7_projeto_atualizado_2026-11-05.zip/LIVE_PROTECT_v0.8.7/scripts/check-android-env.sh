#!/usr/bin/env bash
set -u

ok=0
missing=0
report() { printf '%-28s %s\n' "$1" "$2"; }

if command -v java >/dev/null 2>&1; then
  jv="$(java -version 2>&1 | awk -F '"' 'NR==1 {print $2}')"
  jm="${jv%%.*}"
  report "JDK" "${jv:-detectado}"
  [[ -n "$jm" && "$jm" -ge 17 ]] || { report "JDK requisito" "FALTA JDK 17+"; missing=1; }
else
  report "JDK" "AUSENTE"; missing=1
fi

if [[ -x "./gradlew" ]]; then
  gv="$(./gradlew --version 2>/dev/null | sed -n 's/^Gradle //p' | head -n1)"
elif command -v gradle >/dev/null 2>&1; then
  gv="$(gradle --version 2>/dev/null | sed -n 's/^Gradle //p' | head -n1)"
else
  gv=""
fi
if [[ -n "$gv" ]]; then report "Gradle" "$gv"; else report "Gradle 8.9" "AUSENTE"; missing=1; fi

sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -n "$sdk" ]]; then
  report "Android SDK" "definido"
  [[ -f "$sdk/platforms/android-35/android.jar" ]] || { report "Platform 35" "AUSENTE"; missing=1; }
  for tool in apksigner zipalign aapt; do
    [[ -x "$sdk/build-tools/35.0.0/$tool" ]] || { report "$tool 35.0.0" "AUSENTE"; missing=1; }
  done
  [[ -x "$sdk/platform-tools/adb" ]] || report "adb" "AUSENTE (necessário para instalação física)"
else
  report "Android SDK" "AUSENTE (ANDROID_SDK_ROOT/ANDROID_HOME)"; missing=1
fi

for name in LP_STORE_FILE LP_STORE_PASSWORD LP_KEY_ALIAS LP_KEY_PASSWORD; do
  if [[ -n "${!name:-}" ]]; then report "$name" "definido (valor oculto)"; else report "$name" "não definido"; fi
done
if [[ -n "${LP_STORE_FILE:-}" && -f "${LP_STORE_FILE}" ]]; then
  report "Keystore informado" "arquivo presente"
elif [[ -n "${LP_STORE_FILE:-}" ]]; then
  report "Keystore informado" "arquivo não encontrado"
else
  report "Keystore informado" "não configurado neste ambiente"
fi

if [[ "$missing" -eq 0 ]]; then
  report "Resultado" "DEPENDÊNCIAS DE BUILD PRESENTES"
else
  report "Resultado" "BLOQUEADO: dependências ausentes"
  exit 2
fi
