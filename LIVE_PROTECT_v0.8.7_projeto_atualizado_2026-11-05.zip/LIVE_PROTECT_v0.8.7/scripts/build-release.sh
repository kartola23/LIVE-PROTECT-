#!/usr/bin/env bash
set -euo pipefail

: "${LP_STORE_FILE:?Defina LP_STORE_FILE com o caminho absoluto do keystore release}"
: "${LP_STORE_PASSWORD:?Defina LP_STORE_PASSWORD no ambiente}"
: "${LP_KEY_ALIAS:?Defina LP_KEY_ALIAS no ambiente}"
: "${LP_KEY_PASSWORD:?Defina LP_KEY_PASSWORD no ambiente}"

if [[ ! -f "$LP_STORE_FILE" ]]; then
  echo "Keystore não encontrado: $LP_STORE_FILE" >&2
  exit 1
fi

SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK_DIR" || ! -f "$SDK_DIR/platforms/android-35/android.jar" ]]; then
  echo "Android SDK Platform 35 não encontrado. Defina ANDROID_SDK_ROOT/ANDROID_HOME." >&2
  exit 1
fi

if ! command -v java >/dev/null 2>&1; then
  echo "JDK não encontrado. Instale JDK 17 ou superior." >&2
  exit 1
fi
JAVA_VERSION="$(java -version 2>&1 | awk -F '"' 'NR==1 {print $2}')"
JAVA_MAJOR="${JAVA_VERSION%%.*}"
if [[ -z "$JAVA_MAJOR" || "$JAVA_MAJOR" -lt 17 ]]; then
  echo "JDK 17 ou superior é obrigatório; versão detectada: ${JAVA_MAJOR:-desconhecida}" >&2
  exit 1
fi

if [[ -x "./gradlew" ]]; then
  GRADLE=(./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "Gradle não encontrado (nem gradlew). Instale Gradle 8.9 ou disponibilize o wrapper." >&2
  exit 1
fi
GRADLE_VERSION="$("${GRADLE[@]}" --version | sed -n 's/^Gradle \([0-9][^ ]*\)$/\1/p' | head -n1)"
if [[ "$GRADLE_VERSION" != "8.9" ]]; then
  echo "Este projeto requer Gradle 8.9; versão detectada: ${GRADLE_VERSION:-desconhecida}" >&2
  exit 1
fi

BUILD_TOOLS="$SDK_DIR/build-tools/35.0.0"
APKSIGNER="$BUILD_TOOLS/apksigner"
ZIPALIGN="$BUILD_TOOLS/zipalign"
AAPT="$BUILD_TOOLS/aapt"
for tool in "$APKSIGNER" "$ZIPALIGN" "$AAPT"; do
  if [[ ! -x "$tool" ]]; then
    echo "Ferramenta Android ausente: $tool" >&2
    exit 1
  fi
done

"${GRADLE[@]}" --no-daemon :app:assembleRelease
APK="app/build/outputs/apk/release/app-release.apk"
if [[ ! -s "$APK" ]]; then
  echo "Build terminou sem gerar o APK esperado: $APK" >&2
  exit 1
fi

"$ZIPALIGN" -c -v 4 "$APK"
"$APKSIGNER" verify --verbose --print-certs "$APK"
BADGING="$("$AAPT" dump badging "$APK")"
grep -q "package: name='br.com.liveprotect'" <<<"$BADGING"
printf '%s\n' "$BADGING" | grep -E "^(package:|sdkVersion:|targetSdkVersion:)" || true

echo "APK release alinhado, assinado e validado: $APK"
echo "A instalação em aparelho físico/emulador ainda deve ser verificada com adb install."
