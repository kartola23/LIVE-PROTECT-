from datetime import datetime, timedelta, timezone
from typing import Literal
from pydantic import BaseModel, Field, field_validator

class LiveEvent(BaseModel):
    live_id: str = Field(min_length=1, max_length=120)
    creator_id: str = Field(min_length=1, max_length=120)
    source: Literal["authorized_connector", "manual_test"] = "manual_test"
    event_type: Literal["comment", "viewer_join", "system_signal"]
    user_id: str = Field(default="unknown", max_length=120)
    text: str = Field(default="", max_length=2000)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_validator("live_id", "creator_id", "user_id", mode="before")
    @classmethod
    def trim_event_identifiers(cls, value):
        return value.strip() if isinstance(value, str) else value

    @field_validator("occurred_at")
    @classmethod
    def require_timezone_and_reasonable_window(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("occurred_at must include a timezone, preferably UTC")
        now = datetime.now(timezone.utc)
        normalized = value.astimezone(timezone.utc)
        if normalized > now + timedelta(minutes=5):
            raise ValueError("occurred_at cannot be more than 5 minutes in the future")
        if normalized < now - timedelta(days=7):
            raise ValueError("occurred_at is outside the 7-day ingestion window")
        return value

class Alert(BaseModel):
    id: int
    live_id: str
    creator_id: str
    category: str
    severity: Literal["low", "medium", "high"]
    summary: str
    evidence: str
    created_at: datetime
    source: str

class PartnerCreate(BaseModel):
    display_name: str = Field(min_length=2, max_length=100)
    creator_id: str = Field(min_length=1, max_length=120)

    @field_validator("display_name", "creator_id", mode="before")
    @classmethod
    def trim_identifiers(cls, value):
        return value.strip() if isinstance(value, str) else value

class PartnerLogin(BaseModel):
    partner_id: str = Field(min_length=1, max_length=80)
    access_code: str = Field(min_length=20, max_length=200)

    @field_validator("partner_id", "access_code", mode="before")
    @classmethod
    def trim_credentials(cls, value):
        return value.strip() if isinstance(value, str) else value

class PartnerCreated(BaseModel):
    id: str
    display_name: str
    creator_id: str
    active: bool
    created_at: datetime
    access_code: str

class PartnerPublic(BaseModel):
    id: str
    display_name: str
    creator_id: str
    active: bool
    created_at: datetime

class PartnerSession(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"
    expires_at: datetime
    partner: PartnerPublic
