from .base import LiveProvider, EventHandler

class IndependentProvider(LiveProvider):
    """
    Adapter placeholder for an independently maintained TikTok LIVE event client.

    Do not treat this adapter as an official TikTok integration. Third-party clients
    can break when platform internals change and may be restricted by platform terms.
    Install and wire a reviewed provider implementation only after legal/security review.
    """
    name = "independent"

    def __init__(self):
        self._connected = False

    async def connect(self, room_id: str, on_event: EventHandler) -> None:
        raise RuntimeError(
            "Independent provider is not wired. Configure a reviewed compatible client "
            "and verify current platform terms before enabling."
        )

    async def disconnect(self) -> None:
        self._connected = False
