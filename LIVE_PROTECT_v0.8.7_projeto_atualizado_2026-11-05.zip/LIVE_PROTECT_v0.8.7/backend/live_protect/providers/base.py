from abc import ABC, abstractmethod
from typing import Callable, Any

EventHandler = Callable[[dict[str, Any]], None]

class LiveProvider(ABC):
    name: str

    @abstractmethod
    async def connect(self, room_id: str, on_event: EventHandler) -> None:
        """Connect to an authorized live event source and forward normalized events."""
        raise NotImplementedError

    @abstractmethod
    async def disconnect(self) -> None:
        raise NotImplementedError
