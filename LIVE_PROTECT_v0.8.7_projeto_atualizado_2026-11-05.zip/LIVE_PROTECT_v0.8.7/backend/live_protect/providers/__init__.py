from .base import LiveProvider
from .independent import IndependentProvider
from .official import OfficialProvider

def get_provider(mode: str) -> LiveProvider:
    if mode == "independent":
        return IndependentProvider()
    if mode == "official":
        return OfficialProvider()
    raise ValueError("mode must be 'independent' or 'official'")
