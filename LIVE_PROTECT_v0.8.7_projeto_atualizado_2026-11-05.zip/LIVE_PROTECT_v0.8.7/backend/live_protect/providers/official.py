from .base import LiveProvider, EventHandler

class OfficialProvider(LiveProvider):
    """
    Future adapter for a TikTok-authorized API or partner integration.

    This remains disabled until the project has documented access, credentials,
    scopes, and an approved product/API that actually exposes the required LIVE events.
    """
    name = "official"

    async def connect(self, room_id: str, on_event: EventHandler) -> None:
        raise RuntimeError(
            "Official provider is not configured. Add only a TikTok-approved API "
            "that explicitly grants access to the required LIVE events."
        )

    async def disconnect(self) -> None:
        return None
