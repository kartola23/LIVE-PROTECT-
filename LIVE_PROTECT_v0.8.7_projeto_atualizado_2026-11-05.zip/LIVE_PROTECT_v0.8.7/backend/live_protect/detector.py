import re
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from threading import RLock
from typing import Callable

# Regras heurísticas iniciais. Elas apontam padrões, não provam invasão ou autoria.
THREAT_TERMS = (
    "vou derrubar sua live", "derrubar a live", "invadir sua conta",
    "roubar sua conta", "te hackear", "ataque ddos", "ameaça"
)

class Detector:
    def __init__(self, cooldown_store: Callable | None = None):
        self.cooldown_store = cooldown_store
        self._state_lock = RLock()
        self.recent_comments = defaultdict(lambda: deque(maxlen=30))
        self.user_messages = defaultdict(lambda: deque(maxlen=12))
        self.max_tracked_users = 5000
        self.max_tracked_lives = 1000
        # A single continuing pattern should not create one alert per incoming event.
        self.last_pattern_alerts = {}

    def _allow_pattern_alert(self, key, now, cooldown_seconds=60):
        previous = self.last_pattern_alerts.get(key)
        if previous is not None:
            elapsed = now - previous
            # Also suppress out-of-order/replayed events: a negative delta must
            # never reopen the alert gate and create a duplicate notification.
            if elapsed < timedelta(seconds=cooldown_seconds):
                return False
        if self.cooldown_store is not None:
            allowed, effective_last_alert = self.cooldown_store(key, now, cooldown_seconds)
            self.last_pattern_alerts[key] = effective_last_alert
            return allowed
        self.last_pattern_alerts[key] = now
        return True

    def _bound_state(self, now):
        if len(self.user_messages) > self.max_tracked_users:
            for key, history in list(self.user_messages.items()):
                # Events can arrive out of order. Use the newest observed event
                # timestamp, not the last appended element, when pruning state.
                newest = max((timestamp for timestamp, _ in history), default=None)
                if newest is None or now - newest > timedelta(minutes=2):
                    self.user_messages.pop(key, None)
            while len(self.user_messages) > self.max_tracked_users:
                self.user_messages.pop(next(iter(self.user_messages)), None)
        if len(self.recent_comments) > self.max_tracked_lives:
            for key, history in list(self.recent_comments.items()):
                # The deque is in arrival order, not necessarily event-time order.
                newest = max(history, default=None)
                if newest is None or now - newest > timedelta(minutes=2):
                    self.recent_comments.pop(key, None)
            while len(self.recent_comments) > self.max_tracked_lives:
                self.recent_comments.pop(next(iter(self.recent_comments)), None)
        if len(self.last_pattern_alerts) > self.max_tracked_lives * 30:
            cutoff = now - timedelta(minutes=2)
            for key, alerted_at in list(self.last_pattern_alerts.items()):
                if alerted_at < cutoff:
                    self.last_pattern_alerts.pop(key, None)
            while len(self.last_pattern_alerts) > self.max_tracked_lives * 30:
                self.last_pattern_alerts.pop(next(iter(self.last_pattern_alerts)), None)

    def analyze(self, event):
        # FastAPI may call this synchronous endpoint from multiple worker threads.
        # Protect the in-memory rolling windows and per-process cooldown cache.
        with self._state_lock:
            return self._analyze_locked(event)

    def _analyze_locked(self, event):
        if event.event_type != "comment" or not event.text.strip():
            return []

        now = event.occurred_at
        key = (event.creator_id, event.live_id, event.user_id)
        text = re.sub(r"\s+", " ", event.text.lower()).strip()
        findings = []

        if any(term in text for term in THREAT_TERMS):
            findings.append({
                "category": "threat_language",
                "severity": "high",
                "summary": "Comentário com linguagem de ameaça ou intenção de ataque",
                "evidence": event.text[:300],
            })

        # Do not merge anonymous events into one fictitious user.
        if event.user_id and event.user_id != "unknown":
            history = self.user_messages[key]
            history.append((now, text))
            recent = [msg for ts, msg in history if timedelta(0) <= now - ts <= timedelta(seconds=45)]
        else:
            recent = []
        if (len(recent) >= 4 and len(set(recent)) <= 2 and
                self._allow_pattern_alert(("repeated_spam", *key), now)):
            findings.append({
                "category": "repeated_spam",
                "severity": "medium",
                "summary": "Padrão de comentários repetitivos em curto intervalo",
                "evidence": f"{len(recent)} mensagens em até 45 segundos; conteúdo repetido",
            })

        live_key = (event.creator_id, event.live_id)
        live_history = self.recent_comments[live_key]
        live_history.append(now)
        burst = [ts for ts in live_history if timedelta(0) <= now - ts <= timedelta(seconds=10)]
        if (len(burst) >= 25 and
                self._allow_pattern_alert(("comment_burst", *live_key), now)):
            findings.append({
                "category": "comment_burst",
                "severity": "medium",
                "summary": "Volume de comentários acima do limite inicial configurado",
                "evidence": f"{len(burst)} comentários em até 10 segundos",
            })

        self._bound_state(now)
        return findings
