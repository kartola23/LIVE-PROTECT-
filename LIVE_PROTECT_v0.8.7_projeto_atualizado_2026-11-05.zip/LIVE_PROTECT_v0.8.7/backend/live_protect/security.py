import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import Header, HTTPException
from . import storage

API_TOKEN = os.getenv("LIVE_PROTECT_API_TOKEN", "")
CONNECTOR_TOKEN = os.getenv("LIVE_PROTECT_CONNECTOR_TOKEN", "")
OWNER_CREATOR_ID = os.getenv("LIVE_PROTECT_OWNER_CREATOR_ID", "").strip()
SESSION_HOURS = 12

def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def login_attempt_keys(client_host: str, partner_id: str) -> tuple[str, str]:
    """Return opaque HMAC keys for per-origin and per-partner login throttles.

    The origin limit mitigates credential spraying from one network source; the
    partner limit prevents distributed guessing against one partner account.
    Neither raw address nor partner identifier is persisted in SQLite.
    """
    secret = (API_TOKEN or "live-protect-development-rate-limit-key").encode("utf-8")
    origin_payload = f"origin\0{client_host.strip()}".encode("utf-8")
    partner_payload = f"partner\0{partner_id.strip().casefold()}".encode("utf-8")
    origin_key = hmac.new(secret, origin_payload, hashlib.sha256).hexdigest()
    partner_key = hmac.new(secret, partner_payload, hashlib.sha256).hexdigest()
    return origin_key, partner_key

def require_api_token(authorization: str | None = Header(default=None)):
    if not API_TOKEN and os.getenv("LIVE_PROTECT_ALLOW_INSECURE_DEV") == "1":
        return True
    if not API_TOKEN:
        raise HTTPException(status_code=503, detail="API token is not configured")
    expected = f"Bearer {API_TOKEN}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return True

def authenticate_partner(partner_id: str, access_code: str):
    partner = storage.authenticate_partner(partner_id, _token_hash(access_code))
    if partner is None:
        raise HTTPException(status_code=401, detail="Credenciais de parceiro inválidas ou revogadas")
    token = secrets.token_urlsafe(40)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=SESSION_HOURS)
    storage.create_partner_session(partner_id, _token_hash(token), expires_at.isoformat())
    return token, expires_at, partner

def require_api_access(authorization: str | None = Header(default=None)):
    if API_TOKEN and authorization:
        if secrets.compare_digest(authorization, f"Bearer {API_TOKEN}"):
            return {"role": "owner"}
    if not authorization or not authorization.startswith("Bearer "):
        if not API_TOKEN and os.getenv("LIVE_PROTECT_ALLOW_INSECURE_DEV") == "1":
            return {"role": "owner"}
        if not API_TOKEN:
            raise HTTPException(status_code=503, detail="API token is not configured")
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="Unauthorized")
    partner = storage.get_partner_session(_token_hash(token))
    if partner is None:
        raise HTTPException(status_code=401, detail="Sessão inválida, expirada ou revogada")
    return {"role": "partner", **partner}


def require_connector_token(authorization: str | None):
    """Accept events marked as authorized only from a separately trusted connector."""
    if not CONNECTOR_TOKEN:
        raise HTTPException(status_code=503, detail="Connector token is not configured")
    expected = f"Bearer {CONNECTOR_TOKEN}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Unauthorized connector")
    return {"role": "connector"}


def connector_creator_is_authorized(creator_id: str) -> bool:
    if OWNER_CREATOR_ID and secrets.compare_digest(OWNER_CREATOR_ID, creator_id):
        return True
    return storage.has_active_partner_for_creator(creator_id)
