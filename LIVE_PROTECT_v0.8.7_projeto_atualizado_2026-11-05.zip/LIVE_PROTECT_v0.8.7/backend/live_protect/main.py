from contextlib import asynccontextmanager
from datetime import datetime, timezone
import hashlib
import secrets
import uuid
from fastapi import FastAPI, Query, Depends, HTTPException, Request, Header
from .schemas import LiveEvent, Alert, PartnerCreate, PartnerLogin, PartnerCreated, PartnerPublic, PartnerSession
from .detector import Detector
from . import storage, security
from .security import require_api_token, require_api_access, require_connector_token, authenticate_partner

detector = Detector(cooldown_store=storage.allow_pattern_alert)

@asynccontextmanager
async def lifespan(app: FastAPI):
    storage.initialize()
    yield

app = FastAPI(title="LIVE PROTECT API", version="0.8.7",
              description="API inicial para analisar eventos de lives autorizadas.", lifespan=lifespan)

@app.get("/health")
def health():
    return {"status": "ok", "service": "LIVE PROTECT API", "version": "0.8.7"}

@app.get("/providers")
def providers():
    return {"available_adapters": ["independent", "official"],
            "status": {"independent": "not_connected_review_required",
                       "official": "disabled_pending_tiktok_approval"},
            "operational": False,
            "note": "Os adaptadores são estruturas. Nenhum recebe eventos reais neste pacote."}

@app.get("/owner/verify")
def verify_owner(creator_id: str = Query(min_length=1, max_length=120), _owner=Depends(require_api_token)):
    if not security.OWNER_CREATOR_ID:
        raise HTTPException(status_code=503, detail="LIVE_PROTECT_OWNER_CREATOR_ID não está configurado")
    if not secrets.compare_digest(creator_id.strip(), security.OWNER_CREATOR_ID):
        raise HTTPException(status_code=403, detail="ID não corresponde ao criador proprietário configurado")
    return {"status": "ok", "role": "owner", "creator_id": security.OWNER_CREATOR_ID}

@app.post("/partners", response_model=PartnerCreated)
def create_partner(payload: PartnerCreate, _owner=Depends(require_api_token)):
    partner_id = str(uuid.uuid4())
    access_code = secrets.token_urlsafe(32)
    created = storage.create_partner(partner_id, payload.display_name.strip(),
        payload.creator_id.strip(), hashlib.sha256(access_code.encode("utf-8")).hexdigest())
    return {**created, "access_code": access_code}

@app.get("/partners", response_model=list[PartnerPublic])
def get_partners(_owner=Depends(require_api_token)):
    return storage.list_partners()

@app.post("/partners/{partner_id}/revoke")
def disable_partner(partner_id: str, _owner=Depends(require_api_token)):
    if not storage.revoke_partner(partner_id):
        raise HTTPException(status_code=404, detail="Parceiro não encontrado ou já revogado")
    return {"status": "revoked", "partner_id": partner_id}

@app.post("/auth/partner-login", response_model=PartnerSession)
def partner_login(payload: PartnerLogin, request: Request):
    # Persist only opaque HMACs: one throttle per source and another per partner.
    # Five failures lock a partner for 15 minutes; 30 failures bound one source
    # without allowing guesses against one account from many different networks.
    client_host = request.client.host if request.client else "unknown"
    origin_key, partner_key = security.login_attempt_keys(client_host, payload.partner_id)
    if storage.login_is_locked(origin_key) or storage.login_is_locked(partner_key):
        raise HTTPException(status_code=429, detail="Muitas tentativas. Aguarde 15 minutos.")
    try:
        token, expires_at, partner = authenticate_partner(payload.partner_id, payload.access_code)
    except HTTPException as exc:
        if exc.status_code == 401:
            storage.register_login_failure(origin_key, max_failures=30)
            storage.register_login_failure(partner_key, max_failures=5)
        raise
    storage.clear_login_attempts(origin_key)
    storage.clear_login_attempts(partner_key)
    return {"access_token": token, "expires_at": expires_at,
            "partner": {"id": partner["id"], "display_name": partner["display_name"],
                        "creator_id": partner["creator_id"], "active": bool(partner["active"]),
                        "created_at": partner["created_at"]}}

@app.post("/events/analyze", response_model=list[Alert])
def analyze_event(event: LiveEvent, authorization: str | None = Header(default=None, alias="Authorization")):
    # 'authorized_connector' is not a user-selectable trust claim: it requires
    # a separate server-to-server secret and cannot be asserted by owner/partner tokens.
    if event.source == "authorized_connector":
        principal = require_connector_token(authorization)
        if not security.connector_creator_is_authorized(event.creator_id):
            raise HTTPException(status_code=403, detail="Criador não autorizado para ingestão do conector")
    else:
        principal = require_api_access(authorization)
    if principal["role"] == "partner" and event.creator_id != principal["creator_id"]:
        raise HTTPException(status_code=403, detail="Parceiro não autorizado para este criador")
    results = []
    for finding in detector.analyze(event):
        alert_id = storage.save_alert(event, finding)
        results.append({"id": alert_id, "live_id": event.live_id, "creator_id": event.creator_id,
            **finding, "created_at": datetime.now(timezone.utc), "source": event.source})
    return results

@app.get("/alerts", response_model=list[Alert])
def get_alerts(creator_id: str = Query(min_length=1), limit: int = Query(100, ge=1, le=500),
               principal=Depends(require_api_access)):
    if principal["role"] == "partner" and creator_id != principal["creator_id"]:
        raise HTTPException(status_code=403, detail="Parceiro não autorizado para este criador")
    return storage.list_alerts(creator_id, limit)
