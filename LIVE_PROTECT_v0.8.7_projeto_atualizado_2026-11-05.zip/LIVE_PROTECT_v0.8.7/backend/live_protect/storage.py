import hashlib
import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta, timezone

DEFAULT_DB_PATH = Path(__file__).resolve().parent.parent / "live_protect.db"

def database_path() -> Path:
    return Path(os.getenv("LIVE_PROTECT_DB_PATH", str(DEFAULT_DB_PATH))).expanduser()

def connect():
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def initialize():
    with connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, live_id TEXT NOT NULL,
            creator_id TEXT NOT NULL, category TEXT NOT NULL, severity TEXT NOT NULL,
            summary TEXT NOT NULL, evidence TEXT NOT NULL, created_at TEXT NOT NULL,
            source TEXT NOT NULL)''')
        db.execute("CREATE INDEX IF NOT EXISTS idx_alerts_creator_id_id ON alerts(creator_id, id DESC)")
        db.execute('''CREATE TABLE IF NOT EXISTS partners (
            id TEXT PRIMARY KEY, display_name TEXT NOT NULL, creator_id TEXT NOT NULL,
            access_code_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS partner_sessions (
            token_hash TEXT PRIMARY KEY,
            partner_id TEXT NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL, expires_at TEXT NOT NULL)''')
        db.execute("CREATE INDEX IF NOT EXISTS idx_partner_sessions_expiry ON partner_sessions(expires_at)")
        db.execute('''CREATE TABLE IF NOT EXISTS login_attempts (
            attempt_key TEXT PRIMARY KEY, failed_count INTEGER NOT NULL,
            window_started_at TEXT NOT NULL, locked_until TEXT)''')
        db.execute('''CREATE TABLE IF NOT EXISTS detector_cooldowns (
            pattern_key_hash TEXT PRIMARY KEY,
            alerted_at TEXT NOT NULL)''')
        db.execute("CREATE INDEX IF NOT EXISTS idx_detector_cooldowns_alerted_at ON detector_cooldowns(alerted_at)")

def save_alert(event, finding):
    created_at = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        cur = db.execute('''INSERT INTO alerts
            (live_id, creator_id, category, severity, summary, evidence, created_at, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
            (event.live_id, event.creator_id, finding["category"], finding["severity"],
             finding["summary"], finding["evidence"], created_at, event.source))
        return cur.lastrowid

def list_alerts(creator_id, limit=100):
    with connect() as db:
        rows = db.execute('''SELECT * FROM alerts WHERE creator_id = ?
            ORDER BY id DESC LIMIT ?''', (creator_id, limit)).fetchall()
        return [dict(row) for row in rows]

def create_partner(partner_id, display_name, creator_id, access_code_hash):
    created_at = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute('''INSERT INTO partners
            (id, display_name, creator_id, access_code_hash, active, created_at)
            VALUES (?, ?, ?, ?, 1, ?)''',
            (partner_id, display_name, creator_id, access_code_hash, created_at))
    return {"id": partner_id, "display_name": display_name, "creator_id": creator_id,
            "active": True, "created_at": created_at}

def list_partners():
    with connect() as db:
        rows = db.execute('''SELECT id, display_name, creator_id, active, created_at
            FROM partners ORDER BY created_at DESC''').fetchall()
        return [dict(row) | {"active": bool(row["active"])} for row in rows]

def authenticate_partner(partner_id, access_code_hash):
    with connect() as db:
        row = db.execute('''SELECT id, display_name, creator_id, active, created_at
            FROM partners WHERE id = ? AND access_code_hash = ?''',
            (partner_id, access_code_hash)).fetchone()
        if row is None or not row["active"]:
            return None
        return dict(row)

def create_partner_session(partner_id, token_hash, expires_at):
    created_at = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute("DELETE FROM partner_sessions WHERE expires_at <= ?", (created_at,))
        db.execute('''INSERT INTO partner_sessions
            (token_hash, partner_id, created_at, expires_at) VALUES (?, ?, ?, ?)''',
            (token_hash, partner_id, created_at, expires_at))

def get_partner_session(token_hash):
    now = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        row = db.execute('''SELECT p.id, p.display_name, p.creator_id
            FROM partner_sessions s JOIN partners p ON p.id = s.partner_id
            WHERE s.token_hash = ? AND s.expires_at > ? AND p.active = 1''',
            (token_hash, now)).fetchone()
        return dict(row) if row else None

def revoke_partner(partner_id):
    with connect() as db:
        cur = db.execute("UPDATE partners SET active = 0 WHERE id = ? AND active = 1", (partner_id,))
        db.execute("DELETE FROM partner_sessions WHERE partner_id = ?", (partner_id,))
        return cur.rowcount > 0


def login_is_locked(attempt_key, window_minutes=15):
    """Return True while the hashed client key is in its temporary lockout window."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    now_text = now.isoformat()
    with connect() as db:
        row = db.execute("SELECT window_started_at, locked_until FROM login_attempts WHERE attempt_key = ?",
                         (attempt_key,)).fetchone()
        if row is None:
            return False
        if row["locked_until"] and row["locked_until"] > now_text:
            return True
        try:
            started = datetime.fromisoformat(row["window_started_at"])
        except ValueError:
            db.execute("DELETE FROM login_attempts WHERE attempt_key = ?", (attempt_key,))
            return False
        if now - started >= timedelta(minutes=window_minutes):
            db.execute("DELETE FROM login_attempts WHERE attempt_key = ?", (attempt_key,))
        return False

def register_login_failure(attempt_key, max_failures=5, window_minutes=15):
    """Count a failed login; return True when the client is now temporarily locked."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    now_text = now.isoformat()
    with connect() as db:
        # Acquire the SQLite write lock before reading the counter so concurrent
        # failed logins cannot overwrite one another's increments.
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT failed_count, window_started_at FROM login_attempts WHERE attempt_key = ?",
                         (attempt_key,)).fetchone()
        if row is None:
            count, started = 1, now
        else:
            try:
                started = datetime.fromisoformat(row["window_started_at"])
            except ValueError:
                started = now
            if now - started >= timedelta(minutes=window_minutes):
                count, started = 1, now
            else:
                count = int(row["failed_count"]) + 1
        locked_until = (now + timedelta(minutes=window_minutes)).isoformat() if count >= max_failures else None
        db.execute('''INSERT INTO login_attempts(attempt_key, failed_count, window_started_at, locked_until)
            VALUES (?, ?, ?, ?) ON CONFLICT(attempt_key) DO UPDATE SET
            failed_count=excluded.failed_count, window_started_at=excluded.window_started_at,
            locked_until=excluded.locked_until''', (attempt_key, count, started.isoformat(), locked_until))
        return locked_until is not None

def clear_login_attempts(attempt_key):
    with connect() as db:
        db.execute("DELETE FROM login_attempts WHERE attempt_key = ?", (attempt_key,))


def has_active_partner_for_creator(creator_id):
    with connect() as db:
        row = db.execute("SELECT 1 FROM partners WHERE creator_id = ? AND active = 1 LIMIT 1",
                         (creator_id,)).fetchone()
        return row is not None


def allow_pattern_alert(key, occurred_at, cooldown_seconds=60):
    """Atomically persist an alert cooldown without storing raw user/live identifiers.

    Returns (allowed, effective_last_alert_at). SQLite's immediate write lock keeps
    multiple API workers from emitting the same pattern alert at the same time.
    """
    normalized = occurred_at.astimezone(timezone.utc)
    key_json = json.dumps(key, ensure_ascii=False, separators=(",", ":"), default=str)
    key_hash = hashlib.sha256(key_json.encode("utf-8")).hexdigest()
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute(
            "SELECT alerted_at FROM detector_cooldowns WHERE pattern_key_hash = ?",
            (key_hash,),
        ).fetchone()
        if row is not None:
            try:
                previous = datetime.fromisoformat(row["alerted_at"]).astimezone(timezone.utc)
            except (TypeError, ValueError):
                previous = None
            if previous is not None and normalized - previous < timedelta(seconds=cooldown_seconds):
                return False, previous
        db.execute(
            '''INSERT INTO detector_cooldowns(pattern_key_hash, alerted_at) VALUES (?, ?)
               ON CONFLICT(pattern_key_hash) DO UPDATE SET alerted_at = excluded.alerted_at''',
            (key_hash, normalized.isoformat()),
        )
        # Events older than seven days are rejected by the API; retain an extra day
        # so a delayed but still valid event cannot bypass a recently stored cooldown.
        retention_cutoff = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
        db.execute("DELETE FROM detector_cooldowns WHERE alerted_at < ?", (retention_cutoff,))
        return True, normalized
