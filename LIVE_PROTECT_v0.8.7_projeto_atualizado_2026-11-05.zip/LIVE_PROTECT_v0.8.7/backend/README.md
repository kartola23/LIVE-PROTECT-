# LIVE PROTECT API — versão 0.8.7

API FastAPI para análise inicial de eventos autorizados, com histórico SQLite e autorização básica de parceiros por criador.

## Recursos implementados
- Token administrativo Bearer para gestão de parceiros.
- Criação de parceiro com código aleatório exibido uma única vez; o banco guarda somente SHA-256 do código.
- Login de parceiro com sessão Bearer de 12 horas, armazenada somente como hash.
- Escopo por `creator_id`: parceiro só envia eventos e consulta alertas do criador vinculado.
- Revogação invalida imediatamente as sessões ativas.
- SQLite com índices para histórico e expiração de sessões.
- Cooldown de 60 segundos para alertas de spam repetitivo e rajadas contínuas, persistido em SQLite por hash da chave do padrão; o histórico bruto das janelas de detecção permanece em memória.
- Limite de tentativas de login: cinco falhas por parceiro e 30 falhas por origem em janelas de 15 minutos; ambas as chaves são HMAC-SHA-256 e não armazenam IP ou ID de parceiro em claro. A atualização usa `BEGIN IMMEDIATE` para não perder incrementos concorrentes.
- Eventos rejeitam timestamps sem fuso, mais de 5 minutos no futuro ou com mais de 7 dias. Eventos marcados `authorized_connector` exigem `LIVE_PROTECT_CONNECTOR_TOKEN` separado; token de administrador ou parceiro não pode atribuir essa origem. O criador também precisa estar em `LIVE_PROTECT_OWNER_CREATOR_ID` ou ter ao menos um parceiro ativo cadastrado.

## Executar e testar
```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
export LIVE_PROTECT_API_TOKEN='defina-um-segredo-forte'
uvicorn live_protect.main:app --host 127.0.0.1 --port 8000
pytest -q
```

## Rotas
- `GET /owner/verify?creator_id=...` — confirma token administrativo e ID do criador proprietário configurado em `LIVE_PROTECT_OWNER_CREATOR_ID`.
- `POST /partners` — administrador; cria parceiro e retorna `access_code` uma única vez.
- `GET /partners` — lista parceiros sem códigos secretos.
- `POST /partners/{partner_id}/revoke` — revoga parceiro e sessões.
- `POST /auth/partner-login` — troca ID + código por sessão temporária.
- `POST /events/analyze` e `GET /alerts` — aceitam token administrativo ou sessão com escopo.

## Limitações
Configure HTTPS, segredos seguros, proxy confiável para identificação da origem, auditoria, backup e política de retenção antes de produção. O rate limit local não substitui limites no gateway/WAF. Ainda não há convite por e-mail, recuperação de acesso ou MFA. O app Android 0.8.7 já implementa login de parceiro e sessão criptografada; a criação administrativa de parceiros permanece restrita ao endpoint protegido. Os adaptadores TikTok permanecem desligados e não recebem eventos reais. Configurar `LIVE_PROTECT_CONNECTOR_TOKEN` e `LIVE_PROTECT_OWNER_CREATOR_ID` apenas protege o endpoint de ingestão; não cria nem comprova uma conexão LIVE. O detector é heurístico e requer revisão humana. Não usar scraping de credenciais nem contornar controles da plataforma.


Na versão 0.8.7, o detector mantém o cooldown também diante de eventos fora de ordem/replay, evitando alertas repetidos provocados por timestamps anteriores ao último alerta.


### Persistência do cooldown antifraude (0.8.7)
A tabela `detector_cooldowns` guarda o horário do último alerta por chave SHA-256 do padrão. A chave original (creator/live/user/categoria) não é gravada. A operação usa transação `BEGIN IMMEDIATE`, e registros antigos são removidos após oito dias. Isso evita que reiniciar o processo reabra imediatamente um cooldown ainda válido. O histórico de mensagens e janelas de volume continua em memória e não é reconstruído após reinicialização.


### Rate limit de login (0.8.7)
A limitação é aplicada em duas dimensões independentes: cinco falhas por parceiro e 30 falhas por origem em 15 minutos. Isso reduz o risco de uma conta bloquear outras pessoas que compartilham um NAT e também limita tentativas distribuídas contra uma única conta. O servidor persiste somente HMACs dos identificadores, nunca o IP ou o ID do parceiro em texto claro. Em produção, configure `LIVE_PROTECT_API_TOKEN` com segredo forte e limite adicional no gateway/WAF.
