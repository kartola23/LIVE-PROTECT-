# Exemplos de uso da API LIVE PROTECT 0.8.7

Defina a URL e o token administrativo em um ambiente seguro. Não cole segredos em chats, repositórios ou prints.

```bash
export API='https://api.seu-dominio.com'
export OWNER_TOKEN='seu-token-administrativo'
```

## 1. Cadastrar um parceiro

```bash
curl -sS -X POST "$API/partners" \
  -H "Authorization: Bearer $OWNER_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"display_name":"Parceiro 1","creator_id":"id-do-criador-autorizado"}'
```

Guarde `id` e `access_code` com segurança: o código de acesso só aparece nesta resposta.

## 2. Login do parceiro

```bash
curl -sS -X POST "$API/auth/partner-login" \
  -H 'Content-Type: application/json' \
  -d '{"partner_id":"ID_RECEBIDO","access_code":"CODIGO_RECEBIDO"}'
```

A resposta contém `access_token`, válido por 12 horas. Use-o como Bearer token.

## 3. Enviar evento de teste autorizado

```bash
curl -sS -X POST "$API/events/analyze" \
  -H 'Authorization: Bearer TOKEN_DA_SESSAO' \
  -H 'Content-Type: application/json' \
  -d '{"live_id":"live-teste","creator_id":"id-do-criador-autorizado","event_type":"comment","user_id":"viewer-1","text":"vou derrubar sua live","source":"manual_test"}'
```

## 4. Consultar alertas do criador vinculado

```bash
curl -sS "$API/alerts?creator_id=id-do-criador-autorizado" \
  -H 'Authorization: Bearer TOKEN_DA_SESSAO'
```

## 5. Revogar acesso

```bash
curl -sS -X POST "$API/partners/ID_DO_PARCEIRO/revoke" \
  -H "Authorization: Bearer $OWNER_TOKEN"
```

A revogação encerra imediatamente as sessões existentes. Estes exemplos usam `manual_test`; não representam conexão com uma LIVE real.


## Ingestão de eventos de conector confiável (somente após autorização)

A origem `authorized_connector` exige um segredo separado e um criador permitido:

```bash
curl -X POST https://SEU_HOST/events/analyze \
  -H "Authorization: Bearer $LIVE_PROTECT_CONNECTOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"live_id":"live-123","creator_id":"ID_AUTORIZADO","event_type":"comment","user_id":"viewer-9","text":"vou derrubar sua live","source":"authorized_connector"}'
```

O `creator_id` precisa corresponder a `LIVE_PROTECT_OWNER_CREATOR_ID` ou a um criador com parceiro ativo cadastrado. A configuração do token não liga um conector; nenhuma fonte real de TikTok LIVE acompanha este projeto ainda.

Eventos de teste devem usar `source: "manual_test"` e token administrativo ou sessão de parceiro. O app Android 0.8.7 permite criar um parceiro com token administrativo, entrar com o código emitido e consultar alertas.


## Validar acesso do proprietário

O app pode validar o token administrativo sem armazená-lo e só iniciar a sessão em memória quando o `creator_id` coincidir com `LIVE_PROTECT_OWNER_CREATOR_ID`:

```bash
curl "https://SEU_HOST/owner/verify?creator_id=SEU_CREATOR_ID" \
  -H "Authorization: Bearer $LIVE_PROTECT_API_TOKEN"
```
