from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from live_protect import storage
from live_protect import security
from live_protect.detector import Detector
from live_protect.main import app
from live_protect.schemas import LiveEvent


def test_health_and_provider_status(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'health.db')
    with TestClient(app) as client:
        health = client.get('/health')
        assert health.status_code == 200
        assert health.json()['version'] == '0.8.7'
        providers = client.get('/providers').json()
        assert providers['operational'] is False
        assert providers['status']['official'] == 'disabled_pending_tiktok_approval'


def test_manual_event_requires_api_token(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'test.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'test-secret-token')
    payload = {
        'live_id': 'live-123', 'creator_id': 'creator-1', 'event_type': 'comment',
        'user_id': 'viewer-9', 'text': 'vou derrubar sua live', 'source': 'manual_test'
    }
    with TestClient(app) as client:
        assert client.post('/events/analyze', json=payload).status_code == 401
        response = client.post(
            '/events/analyze', json=payload,
            headers={'Authorization': 'Bearer test-secret-token'},
        )
        assert response.status_code == 200
        alerts = response.json()
        assert len(alerts) == 1
        assert alerts[0]['category'] == 'threat_language'
        history = client.get(
            '/alerts?creator_id=creator-1',
            headers={'Authorization': 'Bearer test-secret-token'},
        )
        assert history.status_code == 200
        assert len(history.json()) == 1


def test_detector_repeated_spam_and_non_comment():
    detector = Detector()
    start = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-1', creator_id='creator-1', event_type='comment',
        user_id='viewer-1', text='segue de volta', occurred_at=start,
    )
    assert detector.analyze(event) == []
    for offset in (5, 10, 15):
        event = event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)})
        findings = detector.analyze(event)
    assert any(item['category'] == 'repeated_spam' for item in findings)

    join_event = event.model_copy(update={'event_type': 'viewer_join', 'text': 'ameaça'})
    assert detector.analyze(join_event) == []


def test_event_rejects_timezone_naive_timestamp():
    try:
        LiveEvent(
            live_id='live-1', creator_id='creator-1', event_type='comment',
            occurred_at=datetime(2026, 10, 30, 12, 0, 0),
        )
    except ValueError:
        return
    raise AssertionError('naive timestamps must be rejected')


def test_partner_login_scope_and_revocation(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'partners.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    monkeypatch.setenv('LIVE_PROTECT_ALLOW_INSECURE_DEV', '0')
    with TestClient(app) as client:
        created = client.post('/partners', json={'display_name': 'Parceiro autorizado',
            'creator_id': 'creator-allowed'}, headers={'Authorization': 'Bearer owner-secret'})
        assert created.status_code == 200
        partner = created.json()
        assert partner['access_code'] and 'access_code_hash' not in partner
        login = client.post('/auth/partner-login', json={'partner_id': partner['id'],
            'access_code': partner['access_code']})
        assert login.status_code == 200
        headers = {'Authorization': f"Bearer {login.json()['access_token']}"}
        allowed = client.post('/events/analyze', json={'live_id': 'live-a',
            'creator_id': 'creator-allowed', 'event_type': 'comment', 'user_id': 'viewer-1',
            'text': 'vou derrubar sua live', 'source': 'manual_test'}, headers=headers)
        assert allowed.status_code == 200 and len(allowed.json()) == 1
        denied = client.post('/events/analyze', json={'live_id': 'live-b',
            'creator_id': 'creator-other', 'event_type': 'comment', 'user_id': 'viewer-2',
            'text': 'vou derrubar sua live', 'source': 'manual_test'}, headers=headers)
        assert denied.status_code == 403
        assert client.get('/alerts?creator_id=creator-other', headers=headers).status_code == 403
        assert len(client.get('/alerts?creator_id=creator-allowed', headers=headers).json()) == 1
        revoked = client.post(f"/partners/{partner['id']}/revoke",
            headers={'Authorization': 'Bearer owner-secret'})
        assert revoked.status_code == 200
        assert client.get('/alerts?creator_id=creator-allowed', headers=headers).status_code == 401


def test_partner_management_requires_owner_token(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'owner.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        response = client.post('/partners', json={'display_name': 'Sem autorização',
            'creator_id': 'creator-1'})
        assert response.status_code == 401


def test_partner_secret_storage_and_invalid_login(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'secrets.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        created = client.post('/partners', json={'display_name': 'Parceiro teste',
            'creator_id': 'creator-secure'}, headers={'Authorization': 'Bearer owner-secret'})
        assert created.status_code == 200
        partner = created.json()
        with storage.connect() as db:
            row = db.execute('SELECT access_code_hash FROM partners WHERE id = ?',
                (partner['id'],)).fetchone()
            assert row['access_code_hash'] != partner['access_code']
            assert len(row['access_code_hash']) == 64
        bad_login = client.post('/auth/partner-login', json={'partner_id': partner['id'],
            'access_code': 'x' * 32})
        assert bad_login.status_code == 401
        listing = client.get('/partners', headers={'Authorization': 'Bearer owner-secret'})
        assert listing.status_code == 200
        assert 'access_code' not in listing.json()[0]


def test_partner_session_expiration(monkeypatch, tmp_path):
    from datetime import datetime, timedelta, timezone
    import hashlib
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'expiry.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        created = client.post('/partners', json={'display_name': 'Parceiro prazo',
            'creator_id': 'creator-expiry'}, headers={'Authorization': 'Bearer owner-secret'})
        assert created.status_code == 200
        partner = created.json()
        login = client.post('/auth/partner-login', json={'partner_id': partner['id'],
            'access_code': partner['access_code']})
        token = login.json()['access_token']
        expired = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        with storage.connect() as db:
            db.execute('UPDATE partner_sessions SET expires_at = ?', (expired,))
        response = client.get('/alerts?creator_id=creator-expiry',
            headers={'Authorization': f'Bearer {token}'})
        assert response.status_code == 401


def test_authorized_connector_source_requires_separate_secret(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'connector.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    monkeypatch.setattr(security, 'CONNECTOR_TOKEN', 'connector-secret')
    monkeypatch.setattr(security, 'OWNER_CREATOR_ID', 'creator-1')
    payload = {'live_id': 'live-connector', 'creator_id': 'creator-1',
        'event_type': 'comment', 'user_id': 'viewer-1',
        'text': 'vou derrubar sua live', 'source': 'authorized_connector'}
    with TestClient(app) as client:
        # An owner token must not be able to label an event as connector-verified.
        denied = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer owner-secret'})
        assert denied.status_code == 401
        accepted = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer connector-secret'})
        assert accepted.status_code == 200
        assert len(accepted.json()) == 1
        assert accepted.json()[0]['source'] == 'authorized_connector'


def test_partner_login_rate_limit_blocks_after_five_failures(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'rate-limit.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        created = client.post('/partners', json={'display_name': 'Parceiro rate limit',
            'creator_id': 'creator-rate'}, headers={'Authorization': 'Bearer owner-secret'})
        partner = created.json()
        bad_payload = {'partner_id': partner['id'], 'access_code': 'x' * 32}
        for _ in range(5):
            response = client.post('/auth/partner-login', json=bad_payload)
            assert response.status_code == 401
        locked = client.post('/auth/partner-login', json={
            'partner_id': partner['id'], 'access_code': partner['access_code']})
        assert locked.status_code == 429


def test_partner_create_trims_and_rejects_blank_names(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'trim.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        ok = client.post('/partners', json={'display_name': '  Parceiro  ',
            'creator_id': '  creator-trim  '}, headers={'Authorization': 'Bearer owner-secret'})
        assert ok.status_code == 200
        assert ok.json()['display_name'] == 'Parceiro'
        assert ok.json()['creator_id'] == 'creator-trim'
        bad = client.post('/partners', json={'display_name': '   ',
            'creator_id': 'creator-trim'}, headers={'Authorization': 'Bearer owner-secret'})
        assert bad.status_code == 422


def test_detector_does_not_merge_unknown_users_or_creators():
    detector = Detector()
    start = datetime.now(timezone.utc)
    base = LiveEvent(live_id='same-live-id', creator_id='creator-A',
        event_type='comment', user_id='unknown', text='segue de volta', occurred_at=start)
    for offset in (0, 5, 10, 15):
        event = base.model_copy(update={'occurred_at': start + timedelta(seconds=offset)})
        assert not any(x['category'] == 'repeated_spam' for x in detector.analyze(event))
    # A different creator using the same live ID must not share burst counters.
    other = base.model_copy(update={'creator_id': 'creator-B', 'user_id': 'viewer-B',
        'text': 'comentário normal', 'occurred_at': start + timedelta(seconds=16)})
    assert not any(x['category'] == 'comment_burst' for x in detector.analyze(other))


def test_connector_source_is_unavailable_without_connector_secret(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'connector-disabled.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    monkeypatch.setattr(security, 'CONNECTOR_TOKEN', '')
    payload = {'live_id': 'live-1', 'creator_id': 'creator-1',
        'event_type': 'comment', 'user_id': 'viewer-1', 'text': 'ameaça',
        'source': 'authorized_connector'}
    with TestClient(app) as client:
        response = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer owner-secret'})
        assert response.status_code == 503


def test_partner_login_clears_failed_attempt_counter_after_success(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'rate-reset.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        created = client.post('/partners', json={'display_name': 'Parceiro reset',
            'creator_id': 'creator-reset'}, headers={'Authorization': 'Bearer owner-secret'})
        partner = created.json()
        for _ in range(4):
            bad = client.post('/auth/partner-login', json={
                'partner_id': partner['id'], 'access_code': 'z' * 32})
            assert bad.status_code == 401
        good = client.post('/auth/partner-login', json={
            'partner_id': partner['id'], 'access_code': partner['access_code']})
        assert good.status_code == 200
        for _ in range(4):
            bad = client.post('/auth/partner-login', json={
                'partner_id': partner['id'], 'access_code': 'z' * 32})
            assert bad.status_code == 401


def test_connector_token_is_scoped_to_registered_creators(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'connector-scope.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    monkeypatch.setattr(security, 'CONNECTOR_TOKEN', 'connector-secret')
    monkeypatch.setattr(security, 'OWNER_CREATOR_ID', 'owner-creator')
    payload = {'live_id': 'live-1', 'creator_id': 'unregistered-creator',
        'event_type': 'comment', 'user_id': 'viewer-1', 'text': 'ameaça',
        'source': 'authorized_connector'}
    with TestClient(app) as client:
        denied = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer connector-secret'})
        assert denied.status_code == 403
        created = client.post('/partners', json={'display_name': 'Parceiro conector',
            'creator_id': 'partner-creator'}, headers={'Authorization': 'Bearer owner-secret'})
        assert created.status_code == 200
        payload['creator_id'] = 'partner-creator'
        allowed = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer connector-secret'})
        assert allowed.status_code == 200
        revoked = client.post(f"/partners/{created.json()['id']}/revoke",
            headers={'Authorization': 'Bearer owner-secret'})
        assert revoked.status_code == 200
        after_revoke = client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer connector-secret'})
        assert after_revoke.status_code == 403


def test_comment_burst_threshold_is_scoped_and_detected():
    detector = Detector()
    start = datetime.now(timezone.utc)
    last_findings = []
    for index in range(25):
        event = LiveEvent(
            live_id='live-burst', creator_id='creator-burst', event_type='comment',
            user_id=f'viewer-{index}', text=f'comentario {index}',
            occurred_at=start + timedelta(milliseconds=index * 100),
        )
        last_findings = detector.analyze(event)
    assert any(item['category'] == 'comment_burst' for item in last_findings)


def test_alerts_are_persisted_across_api_lifespans(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'persistent-alerts.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    payload = {'live_id': 'live-persist', 'creator_id': 'creator-persist',
        'event_type': 'comment', 'user_id': 'viewer-persist',
        'text': 'vou derrubar sua live', 'source': 'manual_test'}
    with TestClient(app) as first_client:
        created = first_client.post('/events/analyze', json=payload,
            headers={'Authorization': 'Bearer owner-secret'})
        assert created.status_code == 200 and len(created.json()) == 1
    with TestClient(app) as second_client:
        history = second_client.get('/alerts?creator_id=creator-persist',
            headers={'Authorization': 'Bearer owner-secret'})
        assert history.status_code == 200
        assert len(history.json()) == 1
        assert history.json()[0]['source'] == 'manual_test'


def test_event_rejects_far_future_and_stale_timestamps():
    now = datetime.now(timezone.utc)
    base = {'live_id': 'live-1', 'creator_id': 'creator-1', 'event_type': 'comment'}
    for timestamp in (now + timedelta(minutes=6), now - timedelta(days=8)):
        try:
            LiveEvent(**base, occurred_at=timestamp)
        except ValueError:
            continue
        raise AssertionError('timestamp outside the ingestion window must be rejected')


def test_independent_and_official_providers_do_not_claim_live_connection():
    import asyncio
    from live_protect.providers.independent import IndependentProvider
    from live_protect.providers.official import OfficialProvider

    async def run_checks():
        for provider in (IndependentProvider(), OfficialProvider()):
            try:
                await provider.connect('room-test', lambda event: None)
            except RuntimeError:
                continue
            raise AssertionError(f'{provider.name} provider must remain disabled until configured')

    asyncio.run(run_checks())


def test_owner_creator_verification_requires_admin_token_and_exact_id(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'owner-verify.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    monkeypatch.setattr(security, 'OWNER_CREATOR_ID', 'owner-creator-123')
    with TestClient(app) as client:
        missing_auth = client.get('/owner/verify?creator_id=owner-creator-123')
        assert missing_auth.status_code == 401
        wrong_creator = client.get('/owner/verify?creator_id=other-creator',
            headers={'Authorization': 'Bearer owner-secret'})
        assert wrong_creator.status_code == 403
        correct = client.get('/owner/verify?creator_id=owner-creator-123',
            headers={'Authorization': 'Bearer owner-secret'})
        assert correct.status_code == 200
        assert correct.json()['role'] == 'owner'


def test_detector_bounds_in_memory_tracking_state():
    detector = Detector()
    detector.max_tracked_users = 2
    detector.max_tracked_lives = 1
    start = datetime.now(timezone.utc)
    for index in range(4):
        event = LiveEvent(live_id=f'live-{index}', creator_id='creator-bound',
            event_type='comment', user_id=f'user-{index}', text='oi',
            occurred_at=start + timedelta(seconds=index))
        detector.analyze(event)
    assert len(detector.user_messages) <= 2
    assert len(detector.recent_comments) <= 1



def test_owner_partner_list_and_revoke_workflow(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'owner-partners.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    owner_headers = {'Authorization': 'Bearer owner-secret'}
    with TestClient(app) as client:
        created = client.post('/partners', json={
            'display_name': 'Parceiro de auditoria',
            'creator_id': 'creator-audit'
        }, headers=owner_headers)
        assert created.status_code == 200
        partner = created.json()

        before = client.get('/partners', headers=owner_headers)
        assert before.status_code == 200
        listed = next(item for item in before.json() if item['id'] == partner['id'])
        assert listed['active'] is True
        assert 'access_code' not in listed

        revoked = client.post(f"/partners/{partner['id']}/revoke", headers=owner_headers)
        assert revoked.status_code == 200
        after = client.get('/partners', headers=owner_headers)
        assert after.status_code == 200
        revoked_item = next(item for item in after.json() if item['id'] == partner['id'])
        assert revoked_item['active'] is False

        login = client.post('/auth/partner-login', json={
            'partner_id': partner['id'],
            'access_code': partner['access_code']
        })
        assert login.status_code == 401


def test_partner_session_cannot_manage_other_partners(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'partner-no-admin.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        created = client.post('/partners', json={
            'display_name': 'Parceiro limitado',
            'creator_id': 'creator-limited'
        }, headers={'Authorization': 'Bearer owner-secret'})
        partner = created.json()
        login = client.post('/auth/partner-login', json={
            'partner_id': partner['id'],
            'access_code': partner['access_code']
        })
        partner_headers = {'Authorization': f"Bearer {login.json()['access_token']}"}
        assert client.get('/partners', headers=partner_headers).status_code == 401
        assert client.post(f"/partners/{partner['id']}/revoke", headers=partner_headers).status_code == 401


def test_detector_throttles_duplicate_spam_alerts_for_one_minute():
    detector = Detector()
    start = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-spam', creator_id='creator-1', event_type='comment',
        user_id='viewer-spammer', text='entra no meu perfil', occurred_at=start,
    )
    findings = []
    for offset in (0, 5, 10, 15):
        findings = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)}))
    assert any(item['category'] == 'repeated_spam' for item in findings)
    next_findings = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=20)}))
    assert not any(item['category'] == 'repeated_spam' for item in next_findings)
    recovered = []
    for offset in (76, 81, 86, 91):
        recovered = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)}))
    assert any(item['category'] == 'repeated_spam' for item in recovered)


def test_detector_throttles_duplicate_comment_burst_alerts():
    detector = Detector()
    start = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-burst', creator_id='creator-1', event_type='comment',
        user_id='viewer', text='oi', occurred_at=start,
    )
    alerts = []
    for offset in range(25):
        alerts.extend(detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(milliseconds=offset * 300)})))
    assert sum(item['category'] == 'comment_burst' for item in alerts) == 1
    extra = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=8)}))
    assert not any(item['category'] == 'comment_burst' for item in extra)
    second_start = start + timedelta(seconds=70)
    alerts_again = []
    for offset in range(25):
        alerts_again.extend(detector.analyze(event.model_copy(update={'occurred_at': second_start + timedelta(milliseconds=offset * 300)})))
    assert sum(item['category'] == 'comment_burst' for item in alerts_again) == 1


def test_detector_does_not_reopen_cooldown_for_out_of_order_replayed_events():
    detector = Detector()
    start = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-replay', creator_id='creator-1', event_type='comment',
        user_id='viewer-replay', text='mensagem repetida', occurred_at=start,
    )
    triggered = []
    for offset in (0, 5, 10, 15):
        triggered = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)}))
    assert any(item['category'] == 'repeated_spam' for item in triggered)

    # An old event arriving after the alert must not bypass the 60-second gate.
    replayed = detector.analyze(event.model_copy(update={'occurred_at': start + timedelta(seconds=4)}))
    assert not any(item['category'] == 'repeated_spam' for item in replayed)


def test_detector_pruning_keeps_recent_state_when_events_arrive_out_of_order():
    detector = Detector()
    detector.max_tracked_users = 2
    detector.max_tracked_lives = 2
    now = datetime.now(timezone.utc)
    stale = now - timedelta(minutes=11)
    recent = now - timedelta(minutes=1)
    current = now - timedelta(seconds=58)

    events = [
        LiveEvent(live_id='live-old', creator_id='creator-prune', event_type='comment',
                  user_id='viewer-old', text='oi', occurred_at=stale),
        LiveEvent(live_id='live-recent', creator_id='creator-prune', event_type='comment',
                  user_id='viewer-recent', text='oi', occurred_at=recent),
        # Older replay arrives after the recent event for the same user/live.
        LiveEvent(live_id='live-recent', creator_id='creator-prune', event_type='comment',
                  user_id='viewer-recent', text='oi', occurred_at=stale),
        LiveEvent(live_id='live-current', creator_id='creator-prune', event_type='comment',
                  user_id='viewer-current', text='oi', occurred_at=current),
    ]
    for event in events:
        detector.analyze(event)

    assert ('creator-prune', 'live-recent', 'viewer-recent') in detector.user_messages
    assert ('creator-prune', 'live-recent') in detector.recent_comments
    assert len(detector.user_messages) <= detector.max_tracked_users
    assert len(detector.recent_comments) <= detector.max_tracked_lives


def test_pattern_cooldown_survives_detector_recreation(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'cooldown-persistence.db')
    storage.initialize()
    start = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-persist-cooldown', creator_id='creator-persist-cooldown',
        event_type='comment', user_id='viewer-persist-cooldown', text='mensagem repetida',
        occurred_at=start,
    )

    first_detector = Detector(cooldown_store=storage.allow_pattern_alert)
    first_findings = []
    for offset in (0, 5, 10, 15):
        first_findings = first_detector.analyze(
            event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)})
        )
    assert any(item['category'] == 'repeated_spam' for item in first_findings)
    with storage.connect() as db:
        cooldown_rows = db.execute(
            'SELECT pattern_key_hash, alerted_at FROM detector_cooldowns'
        ).fetchall()
    assert len(cooldown_rows) == 1
    assert len(cooldown_rows[0]['pattern_key_hash']) == 64
    assert 'creator-persist-cooldown' not in cooldown_rows[0]['pattern_key_hash']

    # A new Detector simulates an API process restart: the database cooldown
    # must still prevent the same continuous pattern from notifying again.
    restarted_detector = Detector(cooldown_store=storage.allow_pattern_alert)
    restarted_findings = []
    for offset in (20, 25, 30, 35):
        restarted_findings = restarted_detector.analyze(
            event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)})
        )
    assert not any(item['category'] == 'repeated_spam' for item in restarted_findings)

    recovered_findings = []
    for offset in (76, 81, 86, 91):
        recovered_findings = restarted_detector.analyze(
            event.model_copy(update={'occurred_at': start + timedelta(seconds=offset)})
        )
    assert any(item['category'] == 'repeated_spam' for item in recovered_findings)


def test_detector_state_is_safe_under_concurrent_event_ingestion():
    from concurrent.futures import ThreadPoolExecutor

    detector = Detector()
    occurred_at = datetime.now(timezone.utc)
    event = LiveEvent(
        live_id='live-concurrent', creator_id='creator-concurrent',
        event_type='comment', user_id='viewer-concurrent', text='mensagem repetida',
        occurred_at=occurred_at,
    )
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(detector.analyze, [event] * 40))

    repeated_spam_alerts = sum(
        1 for findings in results
        if any(item['category'] == 'repeated_spam' for item in findings)
    )
    assert repeated_spam_alerts == 1
    assert len(detector.user_messages[('creator-concurrent', 'live-concurrent', 'viewer-concurrent')]) == 12


def test_partner_login_throttle_isolated_per_account_and_bounded_per_origin(monkeypatch, tmp_path):
    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'scoped-rate-limit.db')
    monkeypatch.setattr(security, 'API_TOKEN', 'owner-secret')
    with TestClient(app) as client:
        headers = {'Authorization': 'Bearer owner-secret'}
        first = client.post('/partners', json={'display_name': 'Parceiro A',
            'creator_id': 'creator-rate'}, headers=headers).json()
        second = client.post('/partners', json={'display_name': 'Parceiro B',
            'creator_id': 'creator-rate'}, headers=headers).json()

        # Five failures lock only the targeted partner, not every account behind
        # the same NAT/public IP.
        for _ in range(5):
            bad = client.post('/auth/partner-login', json={
                'partner_id': first['id'], 'access_code': 'x' * 32})
            assert bad.status_code == 401
        good_other_partner = client.post('/auth/partner-login', json={
            'partner_id': second['id'], 'access_code': second['access_code']})
        assert good_other_partner.status_code == 200

        # A successful login clears the source counter. Thirty unique bad IDs
        # then trigger the independent per-origin spray limit.
        for index in range(30):
            bad = client.post('/auth/partner-login', json={
                'partner_id': f'unknown-partner-{index}', 'access_code': 'x' * 32})
            assert bad.status_code == 401
        blocked_origin = client.post('/auth/partner-login', json={
            'partner_id': first['id'], 'access_code': first['access_code']})
        assert blocked_origin.status_code == 429

        with storage.connect() as db:
            keys = [row['attempt_key'] for row in db.execute(
                'SELECT attempt_key FROM login_attempts').fetchall()]
        assert keys
        assert all(len(key) == 64 for key in keys)
        assert first['id'] not in ''.join(keys)
        assert 'unknown-partner' not in ''.join(keys)


def test_login_failure_counter_is_atomic_under_concurrent_requests(monkeypatch, tmp_path):
    from concurrent.futures import ThreadPoolExecutor

    monkeypatch.setattr(storage, 'database_path', lambda: tmp_path / 'atomic-login-counter.db')
    storage.initialize()
    with ThreadPoolExecutor(max_workers=12) as pool:
        list(pool.map(lambda _: storage.register_login_failure('opaque-key', max_failures=5), range(12)))

    with storage.connect() as db:
        row = db.execute('SELECT failed_count, locked_until FROM login_attempts WHERE attempt_key = ?',
            ('opaque-key',)).fetchone()
    assert row is not None
    assert row['failed_count'] == 12
    assert row['locked_until'] is not None
