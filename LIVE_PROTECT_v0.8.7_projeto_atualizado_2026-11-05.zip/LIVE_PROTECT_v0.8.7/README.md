# LIVE PROTECT — projeto Android + API (0.8.7)

Projeto em desenvolvimento para análise de eventos de lives próprias ou de parceiros autorizados, com aplicativo Android em Kotlin/Jetpack Compose e API FastAPI. Identidade visual preto e dourado.

## Android 0.8.7
- Login de parceiro por ID e código emitido pelo administrador.
- Acesso do proprietário validado por token administrativo e `creator_id`; token fica somente na memória.
- Criação administrativa de parceiro com código exibido uma única vez.
- **Nova tela administrativa para listar parceiros e revogar acessos**; o backend invalida imediatamente as sessões do parceiro revogado.
- Sessão de parceiro criptografada com AES-GCM via Android Keystore.
- Consulta periódica de alertas a cada 60 segundos enquanto o processo do app está ativo; notificações locais podem ser mostradas quando novos alertas chegam.
- Push em segundo plano não está implementado e exige FCM + serviço de envio no backend.

## API 0.8.7
- Gestão administrativa de parceiros: criar, listar e revogar.
- Sessões temporárias de 12 horas, com tokens armazenados como hashes.
- Escopo de autorização por `creator_id`.
- Limite de cinco falhas por parceiro e 30 falhas por origem em janelas de 15 minutos; as chaves são HMAC-SHA-256 e não armazenam IP ou ID em claro.
- Eventos `authorized_connector` protegidos por segredo separado e escopo de criador permitido.
- Histórico de alertas persistido em SQLite.
- Cooldown de 60 segundos para alertas repetidos de spam/rajada, persistido em SQLite por hash da chave do padrão e preservado após reinício da API.
- Detector protegido por `RLock` para serializar o acesso às janelas em memória quando o FastAPI processa eventos em threads concorrentes.

## Validação e limitações
- Testes de backend registrados em `TEST_REPORT.md`.
- O Kotlin foi alterado, mas **não foi possível compilar o Android** neste ambiente: Gradle, Gradle Wrapper, Android SDK Platform 35 e Build Tools 35.0.0 estão ausentes.
- Java 21 está disponível e atende ao requisito mínimo do Android Gradle Plugin 8.7.3.
- O backend ainda precisa ser publicado em HTTPS para uso remoto.
- Modo independente e adaptador oficial continuam desativados; não há captura de eventos reais de TikTok LIVE.
- O detector é heurístico, pode gerar falsos positivos e exige revisão humana. O cooldown de 60 segundos fica persistido em SQLite; as janelas brutas de comentários permanecem em memória e não são reconstruídas após reinício. Alertas gerados são persistidos em SQLite.
- Não solicita nem armazena senha do TikTok, nem usa scraping de sessão.

Consulte `backend/README.md`, `backend/API_EXAMPLES.md`, `docs/TIKTOK_INTEGRATION_STATUS.md` e `RELEASE_APK.md`.


## Android 0.8.7 — endurecimento de conexão
- A URL base da API rejeita userinfo, query string e fragmento, além de exigir HTTPS e host válido.
- Redirecionamentos HTTP automáticos são desativados para evitar que cabeçalhos Bearer sejam encaminhados a destinos inesperados.
- Cache HTTP desativado para chamadas autenticadas.
- `versionCode` 9 / `versionName` 0.8.7.
## Compilação do APK pelo GitHub (sem PC)
O workflow `.github/workflows/android-apk.yml` compila e verifica um APK debug no GitHub Actions. Consulte `CI_ANDROID.md` para iniciar a compilação pelo navegador do celular e baixar o artefato. A compilação ainda precisa ser executada no GitHub; este pacote não inclui APK.


## 0.8.7 — persistência e concorrência do detector
- Cooldown de alertas antifraude persistido em SQLite por chave hash, com transação imediata e retenção limitada.
- Eventos antigos ou fora de ordem não reabrem a janela de notificação.
- O detector serializa mutações de suas janelas em memória para evitar corridas entre threads.
- O rótulo de versão exibido na tela Sobre e o endpoint `/health` acompanham a versão 0.8.7.


## 0.8.7 — rate limit de login com escopo duplo
- Cinco falhas bloqueiam somente o parceiro alvo por 15 minutos.
- Trinta falhas bloqueiam a origem por 15 minutos, reduzindo credential spraying sem permitir que cinco erros de uma conta bloqueiem todos os usuários atrás do mesmo NAT.
- Os dois identificadores de rate limit são HMAC-SHA-256 e não armazenam IP ou ID de parceiro em claro. Login bem-sucedido limpa os dois contadores; a contagem é serializada no SQLite para evitar perda de incrementos concorrentes.
